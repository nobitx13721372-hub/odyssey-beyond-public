// Builds NFP-Archive.html: one self-contained page (fonts, icons, covers, code inlined) that works opened straight
// from disk and is also what server.mjs serves.
//   node build.mjs [--icons-from=<phosphor assets/regular dir>]   (the flag re-copies the icons the code uses)
//   node build.mjs --free-fonts [--out=<file>]   the version to give to others: OFL fonts only (Vazirmatn, Lalezar)
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const P = (...p) => path.join(here, ...p);
const read = (p) => fs.readFileSync(P(p), "utf8");
const opt = Object.fromEntries(process.argv.slice(2).filter((a) => a.startsWith("--")).map((a) => { const [k, v] = a.slice(2).split("="); return [k, v ?? true]; }));

// Fonts: Vazirmatn + Lalezar are the channel's licensed fonts (internal use only); everything else is OFL.
// --free-fonts (or a copy without the licensed files) builds with Vazirmatn + Lalezar instead: the version to share.
const fontDir = P("assets", "fonts");
const FREE = !!opt["free-fonts"] || !fs.existsSync(path.join(fontDir, "Vazirmatn-SemiBold.ttf"));
const LAT = [
  ["Chakra Petch", 400, "ChakraPetch-Regular.ttf"],
  ["Chakra Petch", 500, "ChakraPetch-Medium.ttf"],
  ["Chakra Petch", 600, "ChakraPetch-SemiBold.ttf"],
];
const FONTS = FREE
  ? [["Vazirmatn", 300, "Vazirmatn-Light.ttf"], ["Vazirmatn", 600, "Vazirmatn-SemiBold.ttf"], ["Vazirmatn", 700, "Vazirmatn-Bold.ttf"], ["Lalezar", 400, "Lalezar-Regular.ttf"], ...LAT]
  : [["Vazirmatn", 300, "Vazirmatn-Light.ttf"], ["Vazirmatn", 600, "Vazirmatn-SemiBold.ttf"], ["Vazirmatn", 700, "Vazirmatn-Bold.ttf"], ["Lalezar", 400, "LalezarCircle.ttf"], ...LAT];
const fontCss = FONTS.map(([fam, w, file]) => {
  const b64 = fs.readFileSync(path.join(fontDir, file)).toString("base64");
  return `@font-face{font-family:"${fam}";font-weight:${w};font-style:normal;font-display:swap;src:url(data:font/ttf;base64,${b64}) format("truetype")}`;
}).join("\n");

// Icons (Phosphor, MIT): every string literal in app.js that names an icon file.
const iconDir = P("vendor", "phosphor-regular");
const app = read("src/app.js");
const literals = new Set([...app.matchAll(/"([a-z0-9-]+)"/g)].map((m) => m[1]));
if (opt["icons-from"]) {
  fs.mkdirSync(iconDir, { recursive: true });
  for (const n of literals) {
    const src = path.join(opt["icons-from"], n + ".svg");
    if (fs.existsSync(src)) fs.copyFileSync(src, path.join(iconDir, n + ".svg"));
  }
}
const icons = {};
for (const f of fs.readdirSync(iconDir)) {
  const n = f.replace(/\.svg$/, "");
  if (literals.has(n)) icons[n] = fs.readFileSync(path.join(iconDir, f), "utf8").trim().replace(/\s+/g, " ");
}
const used = [...app.matchAll(/ic\("([a-z0-9-]+)"/g)].map((m) => m[1]);
const missing = [...new Set(used)].filter((n) => !icons[n]);
if (missing.length) { console.error("missing icons: " + missing.join(", ") + "  (run with --icons-from=…/phosphor/assets/regular)"); process.exit(1); }

// Home covers: assets/covers/<category>.jpg (tools/make-covers.mjs)
const covers = {};
const coverDir = P("assets", "covers");
if (fs.existsSync(coverDir)) for (const f of fs.readdirSync(coverDir)) if (f.endsWith(".jpg")) covers[f.replace(/\.jpg$/, "")] = "data:image/jpeg;base64," + fs.readFileSync(path.join(coverDir, f)).toString("base64");

// </script> inside inlined code would end the tag early.
const safe = (s) => s.replace(/<\/script/gi, "<\\/script");
// the font stacks name the licensed fonts first; the free build names the OFL ones
const css = FREE ? read("src/style.css").replace('"Vazirmatn", "Vazirmatn",', '"Vazirmatn",').replace('"Lalezar", "Vazirmatn",', '"Lalezar", "Vazirmatn",') : read("src/style.css");
let html = read("src/index.html")
  .replace("/*@FONTS*/", () => fontCss)
  .replace("/*@CSS*/", () => css)
  .replace("/*@DATA*/", () => safe(`window.NA_ICONS=${JSON.stringify(icons)};window.NA_COVERS=${JSON.stringify(covers)};`))
  .replace("/*@CORE*/", () => safe(read("src/core.js")))
  .replace("/*@SOURCES*/", () => safe(read("src/sources.js")))
  .replace("/*@CATEGORIES*/", () => safe(read("src/data/categories.js")))
  .replace("/*@DICT*/", () => safe(read("src/data/dict.js")))
  .replace("/*@APP*/", () => safe(app));
const out = opt.out ? path.resolve(String(opt.out)) : P("NFP-Archive.html");
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, html);
console.log(`${path.basename(out)}  ${(html.length / 1024).toFixed(0)} KB  (${Object.keys(icons).length} icons, ${Object.keys(covers).length} covers, ${FREE ? "free fonts" : "channel fonts"})`);
