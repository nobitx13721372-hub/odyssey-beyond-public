// NFP Archive helper: serves NFP-Archive.html on 127.0.0.1 and does what a page can't — downloads straight into a
// folder (several connections per file, like IDM, with resume) and cuts a clip out of a long film with ffmpeg.
// It also runs the page's search over the other free sites (sources.js: Wikimedia Commons, NASA, Coverr, Mixkit,
// museums, and Pexels / Pixabay / Unsplash with your own free key), so sites without CORS work and their files download
// the same way. Node built-ins only; no npm install. Start with start.bat (Windows) / start.command (macOS) or:
//   node server.mjs [--open] [--port=47821] [--lite]      (--lite: serve the page without the helper, for testing)
// Safety: listens on 127.0.0.1 only, every /api call needs the token baked into the served page, the Host header
// must be local (no DNS rebinding), and it only downloads from archive.org, the free sites' file servers, or a link its
// own search returned.
import http from "node:http";
import https from "node:https";
import tls from "node:tls";
import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import crypto from "node:crypto";
import { spawn } from "node:child_process";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const VERSION = "1.0.0";
const args = Object.fromEntries(process.argv.slice(2).map((a) => { const [k, v] = a.replace(/^--/, "").split("="); return [k, v ?? true]; }));
const SETTINGS_FILE = path.join(here, "settings.json");
const JOBS_FILE = path.join(here, "jobs.json");
// an honest name in the sites' logs (Wikimedia refuses anonymous tools)
const UA = `NFP-Archive/${VERSION} (+https://alvana.me)`;
const MAX_ACTIVE = 2;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ------------------------------------------------------------------ settings
const DEFAULTS = { dir: path.join(os.homedir(), "Downloads", "NFP-Archive"), connections: 8, proxy: "", ffmpeg: "ffmpeg", ffprobe: "ffprobe", port: 47821, keys: {} };
// free keys for the optional sources; kept in settings.json, never sent back to the page
const KEYS = ["PEXELS_API_KEY", "PIXABAY_API_KEY", "UNSPLASH_ACCESS_KEY", "EUROPEANA_API_KEY"];
let settings = { ...DEFAULTS };
try { settings = { ...DEFAULTS, ...JSON.parse(fs.readFileSync(SETTINGS_FILE, "utf8")) }; } catch {}
const saveSettings = () => fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
const publicSettings = () => ({ dir: settings.dir, connections: settings.connections, proxy: settings.proxy, keys: Object.fromEntries(KEYS.map((k) => [k, !!(settings.keys || {})[k]])) });

let hasFfmpeg = false;
const which = (bin) => new Promise((res) => {
  const p = spawn(bin, ["-version"], { stdio: "ignore", windowsHide: true });
  p.on("error", () => res(false));
  p.on("exit", (c) => res(c === 0));
});

// ------------------------------------------------------------------ network
const AGENT = new https.Agent({ keepAlive: true, maxSockets: 64 });
// what may be downloaded: archive.org, the free sites' own file servers, and any file the helper's search returned
const CDN = /^(upload\.wikimedia\.org|images-assets\.nasa\.gov|cdn\.coverr\.co|assets\.mixkit\.co|openaccess-cdn\.clevelandart\.org|iiif\.wellcomecollection\.org|images\.pexels\.com|videos\.pexels\.com|cdn\.pixabay\.com|images\.unsplash\.com)$/;
const FOUND = new Set();
function allowedUrl(u) {
  try {
    const x = new URL(u);
    return x.protocol === "https:" && (x.hostname === "archive.org" || x.hostname.endsWith(".archive.org") || CDN.test(x.hostname) || FOUND.has(x.href));
  } catch { return false; }
}
function viaProxy(host, port) {
  return new Promise((resolve, reject) => {
    const p = new URL(settings.proxy);
    const req = http.request({ host: p.hostname, port: p.port || 80, method: "CONNECT", path: `${host}:${port}`, headers: { Host: `${host}:${port}` } });
    req.on("connect", (res, socket) => {
      if (res.statusCode !== 200) { socket.destroy(); return reject(new Error("proxy refused: " + res.statusCode)); }
      resolve(socket);
    });
    req.on("error", reject);
    req.setTimeout(20000, () => req.destroy(new Error("proxy timeout")));
    req.end();
  });
}
async function get(url, { headers = {}, signal } = {}) {
  const u = new URL(url);
  const opts = { method: "GET", host: u.hostname, port: u.port || 443, path: u.pathname + u.search, headers: { "User-Agent": UA, ...headers }, signal, servername: u.hostname };
  if (settings.proxy) {
    const sock = await viaProxy(u.hostname, opts.port);
    const secure = tls.connect({ socket: sock, servername: u.hostname });
    opts.createConnection = () => secure;
    opts.agent = false;
  } else opts.agent = AGENT;
  return new Promise((resolve, reject) => {
    const req = https.request(opts, resolve);
    req.on("error", reject);
    req.setTimeout(45000, () => req.destroy(new Error("timeout")));
    req.end();
  });
}
// Follows archive.org's redirect to the storage node once, so every part request goes straight there.
async function resolveUrl(url) {
  if (!allowedUrl(url)) throw new Error("not a link from the search");
  let cur = url;
  for (let i = 0; i < 6; i++) {
    // the first link is checked above; a site may then send it on to its storage (https only)
    if (!/^https:\/\//i.test(cur)) throw new Error("https only");
    const res = await get(cur, { headers: { Range: "bytes=0-0" } });
    if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
      res.resume();
      cur = new URL(res.headers.location, cur).href;
      continue;
    }
    if (res.statusCode === 206) {
      res.resume();
      const m = /\/(\d+)\s*$/.exec(res.headers["content-range"] || "");
      return { url: cur, total: m ? Number(m[1]) : 0, ranges: true };
    }
    if (res.statusCode === 200) {
      res.destroy();
      return { url: cur, total: Number(res.headers["content-length"] || 0), ranges: false };
    }
    res.resume();
    throw new Error("HTTP " + res.statusCode);
  }
  throw new Error("too many redirects");
}

// ------------------------------------------------------------------ files
const clean = (s, max = 120) =>
  String(s || "file").replace(/[\u0000-\u001f<>:"/\\|?*]+/g, "_").replace(/^[.\s]+|[.\s]+$/g, "").slice(0, max) || "file";
function uniquePath(p) {
  if (!fs.existsSync(p) && !fs.existsSync(p + ".part")) return p;
  const { dir, name, ext } = path.parse(p);
  for (let i = 2; i < 1000; i++) {
    const q = path.join(dir, `${name} (${i})${ext}`);
    if (!fs.existsSync(q) && !fs.existsSync(q + ".part")) return q;
  }
  return p;
}
const csvCell = (s) => `"${String(s ?? "").replace(/"/g, '""')}"`;
function credit(job) {
  const file = path.join(settings.dir, "credits.csv");
  const head = fs.existsSync(file) ? "" : "﻿" + ["file", "title", "item", "licence", "source", "date"].map(csvCell).join(",") + "\n";
  const row = [path.relative(settings.dir, job.file), job.title, job.page || (job.itemId ? `https://archive.org/details/${job.itemId}` : ""), job.licence, job.url, new Date().toISOString().slice(0, 10)].map(csvCell).join(",");
  try { fs.appendFileSync(file, head + row + "\n"); } catch {}
}

// ------------------------------------------------------------------ jobs
let jobs = [];
try { jobs = JSON.parse(fs.readFileSync(JOBS_FILE, "utf8")); } catch {}
for (const j of jobs) if (/queued|running|probing/.test(j.status)) { j.status = "paused"; }
let saveT = 0;
function saveJobs() {
  clearTimeout(saveT);
  saveT = setTimeout(() => {
    const keep = jobs.map(({ id, kind, url, name, file, status, total, done, unit, error, title, itemId, licence, start, end, size, len, created, phase }) => ({ id, kind, url, name, file, status, total, done, unit, error, title, itemId, licence, start, end, size, len, created, phase }));
    try { fs.writeFileSync(JOBS_FILE, JSON.stringify(keep, null, 1)); } catch {}
  }, 400);
}
const view = (j) => ({ id: j.id, kind: j.kind, name: j.name, file: j.file ? path.basename(j.file) : "", status: j.status, total: j.total || 0, done: j.done || 0, unit: j.unit || "B", speed: Math.round(j.speed || 0), error: j.error || "", phase: j.phase || "", created: j.created });
const newId = () => crypto.randomBytes(5).toString("hex");

function pump() {
  const active = jobs.filter((j) => j.status === "running" || j.status === "probing").length;
  const next = jobs.filter((j) => j.status === "queued").slice(0, Math.max(0, MAX_ACTIVE - active));
  for (const j of next) start(j);
}
function start(job) {
  job.status = "probing";
  job.error = "";
  job.ctl = { aborts: new Set() };
  saveJobs();
  const run = job.kind === "clip" ? runClip(job) : runFile(job);
  run.then(() => {
    if (job.status === "probing" || job.status === "running") { job.status = "done"; job.speed = 0; credit(job); }
  }).catch((e) => {
    if (job.status === "running" || job.status === "probing") { job.status = "error"; job.error = String(e && e.message || e).slice(0, 200); }
  }).finally(() => { job.speed = 0; saveJobs(); pump(); });
}
function stop(job, status) {
  job.status = status;
  if (job.ctl) for (const ac of job.ctl.aborts) try { ac.abort(); } catch {}
  if (job.proc) try { job.proc.kill(); } catch {}
  saveJobs();
}

// Download [from, to] of job.src into file (resumable: <file>.part + <file>.part.json), several parts at once.
// A part that finishes early takes over half of the largest part still running.
async function fetchRange(job, file, from, to, { count = true } = {}) {
  const partFile = file + ".part", stateFile = file + ".part.json";
  let segs = null;
  try {
    const st = JSON.parse(fs.readFileSync(stateFile, "utf8"));
    if (st.from === from && st.to === to && fs.existsSync(partFile)) segs = st.segs;
  } catch {}
  const size = to - from + 1;
  if (!segs) {
    const n = Math.max(1, Math.min(Number(settings.connections) || 8, 16, Math.ceil(size / (1 << 20))));
    const step = Math.ceil(size / n);
    segs = Array.from({ length: n }, (_, i) => ({ start: from + i * step, end: Math.min(to, from + (i + 1) * step - 1), pos: from + i * step })).filter((s) => s.start <= s.end);
    fs.writeFileSync(partFile, "");
  }
  const fh = await fsp.open(partFile, "r+");
  const doneNow = () => segs.reduce((a, s) => a + (s.pos - s.start), 0);
  if (count) { job.total = size; job.done = doneNow(); job.unit = "B"; }
  const persist = () => { try { fs.writeFileSync(stateFile, JSON.stringify({ from, to, segs: segs.map(({ start, end, pos }) => ({ start, end, pos })) })); } catch {} };
  let last = job.done || 0, lastT = Date.now();
  const tick = setInterval(() => {
    persist();
    if (!count) return;
    const now = Date.now(), d = job.done - last;
    job.speed = job.speed ? job.speed * 0.6 + (d / ((now - lastT) / 1000)) * 0.4 : d / ((now - lastT) / 1000);
    last = job.done; lastT = now;
  }, 1000);
  const live = () => job.status === "running" || job.status === "probing";
  async function work(seg) {
    while (live()) {
      let tries = 0;
      while (seg.pos <= seg.end && live()) {
        const ac = new AbortController();
        job.ctl.aborts.add(ac);
        try {
          const res = await get(job.src, { headers: { Range: `bytes=${seg.pos}-${seg.end}` }, signal: ac.signal });
          if (res.statusCode !== 206) { res.destroy(); throw new Error("HTTP " + res.statusCode); }
          for await (const chunk of res) {
            const room = seg.end - seg.pos + 1;
            if (room <= 0 || !live()) break;
            const buf = chunk.length > room ? chunk.subarray(0, room) : chunk;
            await fh.write(buf, 0, buf.length, seg.pos - from);
            seg.pos += buf.length;
            if (count) job.done += buf.length;
            tries = 0;
          }
        } catch (e) {
          if (!live()) break;
          if (++tries > 12) throw e;
          await sleep(Math.min(15000, 700 * tries));
        } finally { job.ctl.aborts.delete(ac); }
      }
      // take over half of the biggest remaining part
      const big = segs.filter((s) => s.end - s.pos > 4 << 20).sort((a, b) => (b.end - b.pos) - (a.end - a.pos))[0];
      if (!big || !live()) return;
      const mid = big.pos + Math.floor((big.end - big.pos) / 2);
      const fresh = { start: mid + 1, end: big.end, pos: mid + 1 };
      big.end = mid;
      segs.push(fresh);
      seg = fresh;
    }
  }
  try {
    await Promise.all(segs.filter((s) => s.pos <= s.end).map((s) => work(s)));
  } finally {
    clearInterval(tick);
    persist();
    await fh.close();
  }
  if (!live()) return false;
  if (segs.some((s) => s.pos <= s.end)) throw new Error("incomplete");
  fs.renameSync(partFile, file);
  fs.rmSync(stateFile, { force: true });
  return true;
}

async function runFile(job) {
  const info = await resolveUrl(job.url);
  job.src = info.url;
  job.status = "running";
  fs.mkdirSync(path.dirname(job.file), { recursive: true });
  if (!info.ranges || !info.total) {
    // no ranges: one plain stream, no resume
    const res = await get(job.src);
    if (res.statusCode !== 200) { res.resume(); throw new Error("HTTP " + res.statusCode); }
    job.total = info.total; job.done = 0; job.unit = "B";
    const out = fs.createWriteStream(job.file + ".part");
    for await (const chunk of res) {
      if (job.status !== "running") { res.destroy(); out.close(); return; }
      out.write(chunk);
      job.done += chunk.length;
    }
    await new Promise((r) => out.end(r));
    fs.renameSync(job.file + ".part", job.file);
    return;
  }
  await fetchRange(job, job.file, 0, info.total - 1);
}

// ------------------------------------------------------------------ clips
const runTool = (bin, argv, onLine, job) => new Promise((resolve, reject) => {
  const p = spawn(bin, argv, { windowsHide: true, env: settings.proxy ? { ...process.env, http_proxy: settings.proxy } : process.env });
  if (job) job.proc = p;
  let err = "";
  p.stdout.on("data", (d) => { if (onLine) for (const l of String(d).split(/\r?\n/)) onLine(l); });
  p.stderr.on("data", (d) => { err = (err + d).slice(-4000); });
  p.on("error", reject);
  p.on("exit", (c) => (c === 0 ? resolve(p) : reject(new Error((err.trim().split(/\r?\n/).pop() || "ffmpeg failed").slice(0, 200)))));
  return p;
});
async function probe(file) {
  let out = "";
  await runTool(settings.ffprobe, ["-v", "error", "-show_entries", "format=start_time,duration", "-of", "json", file], (l) => (out += l));
  const f = JSON.parse(out).format || {};
  return { start: Number(f.start_time) || 0, duration: Number(f.duration) || 0 };
}
async function encode(job, input, ss, dur, out, remote) {
  job.phase = "encode";
  job.unit = "s"; job.total = dur; job.done = 0; job.speed = 0;
  const argv = ["-hide_banner", "-nostdin", "-y"];
  if (remote) argv.push("-user_agent", UA, "-reconnect", "1", "-reconnect_on_network_error", "1", "-reconnect_delay_max", "5");
  argv.push("-ss", ss.toFixed(3), "-i", input, "-t", dur.toFixed(3), "-map", "0:v:0", "-map", "0:a:0?",
    "-vf", "yadif=deint=interlaced,scale=trunc(iw*sar/2)*2:ih,setsar=1",
    "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
    "-movflags", "+faststart", "-progress", "pipe:1", out);
  await runTool(settings.ffmpeg, argv, (l) => {
    const m = /^out_time_us=(\d+)/.exec(l);
    if (m) job.done = Math.min(dur, Number(m[1]) / 1e6);
  }, job);
  job.proc = null;
}
// MPEG program/transport streams seek slowly over HTTP (ffmpeg probes the file many times), so for those the
// helper fetches just the byte window around the clip with the fast downloader and cuts it locally.
async function runClip(job) {
  if (!hasFfmpeg) throw new Error("ffmpeg not found");
  const info = await resolveUrl(job.url);
  job.src = info.url;
  job.status = "running";
  fs.mkdirSync(path.dirname(job.file), { recursive: true });
  const dur = job.end - job.start;
  const tmp = job.file + ".src";
  const byteSeek = /\.(mpe?g|mpg|m2v|vob|ts|m2ts|mts)$/i.test(job.name) && info.ranges && info.total && job.len > 0;
  try {
    if (!byteSeek) {
      await encode(job, info.url, job.start, dur, job.file + ".tmp.mp4", true);
    } else {
      job.phase = "piece";
      const head = tmp + ".head";
      await fetchRange(job, head, 0, Math.min(info.total - 1, 3_000_000), { count: false });
      if (job.status !== "running") return;
      const s0 = (await probe(head)).start;
      fs.rmSync(head, { force: true });
      const bps = info.total / job.len;
      let a = Math.max(0, job.start - 10), b = Math.min(job.len, job.end + 8), ok = false;
      for (let i = 0; i < 4 && !ok; i++) {
        const b0 = Math.max(0, Math.floor(a * bps)), b1 = Math.min(info.total - 1, Math.ceil(b * bps));
        fs.rmSync(tmp, { force: true });
        if (!(await fetchRange(job, tmp, b0, b1))) return;
        const c = await probe(tmp);
        const want0 = s0 + job.start, want1 = s0 + job.end;
        if (c.start <= want0 + 0.05 && c.start + c.duration >= want1 - 0.05) {
          await encode(job, tmp, want0 - c.start, dur, job.file + ".tmp.mp4", false);
          ok = true;
        } else {
          if (c.start > want0) a = Math.max(0, a - (c.start - want0) - 8);
          if (c.start + c.duration < want1) b = Math.min(job.len + 30, b + (want1 - c.start - c.duration) + 8);
        }
      }
      if (!ok) throw new Error("could not locate the clip in the file");
    }
    if (job.status !== "running") return;
    fs.renameSync(job.file + ".tmp.mp4", job.file);
  } finally {
    for (const f of [tmp, tmp + ".part", tmp + ".part.json", job.file + ".tmp.mp4"]) if (job.status !== "paused") fs.rmSync(f, { force: true });
  }
}

// ------------------------------------------------------------------ the other free sources
async function nfFetch(url, init = {}) {
  let cur = String(url);
  for (let i = 0; i < 6; i++) {
    const res = await get(cur, { headers: init.headers || {} });
    if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) { res.resume(); cur = new URL(res.headers.location, cur).href; continue; }
    const chunks = [];
    let n = 0;
    for await (const c of res) { chunks.push(c); n += c.length; if (n > 40e6) { res.destroy(); throw new Error("response too big"); } }
    const text = Buffer.concat(chunks).toString("utf8");
    return { ok: res.statusCode >= 200 && res.statusCode < 300, status: res.statusCode, url: cur, headers: { get: (k) => res.headers[String(k).toLowerCase()] ?? null }, text: async () => text, json: async () => JSON.parse(text) };
  }
  throw new Error("too many redirects");
}
const nfCtx = vm.createContext({ fetch: nfFetch, URL, URLSearchParams, AbortSignal, setTimeout, clearTimeout, console });
for (const f of ["core.js", "sources.js"]) vm.runInContext(fs.readFileSync(path.join(here, "src", f), "utf8"), nfCtx, { filename: f });
const NF = nfCtx.NF;
NF.UA = UA;
const useKeys = () => { for (const k of KEYS) NF.keys[k] = (settings.keys || {})[k] || ""; };
useKeys();
// every file a search or a detail returned becomes downloadable
function remember(it) {
  if (FOUND.size > 50000) FOUND.clear();
  for (const u of [it.preview, ...(it.files || []).map((x) => x.url)]) if (u) { try { FOUND.add(new URL(u).href); } catch {} }
}

// ------------------------------------------------------------------ http
const TOKEN = crypto.randomBytes(24).toString("hex");
const send = (res, code, obj) => { res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" }); res.end(JSON.stringify(obj)); };
const body = (req) => new Promise((resolve, reject) => {
  let s = "";
  req.on("data", (d) => { s += d; if (s.length > 1e6) req.destroy(); });
  req.on("end", () => { try { resolve(s ? JSON.parse(s) : {}); } catch (e) { reject(e); } });
  req.on("error", reject);
});
const fmtClip = (s) => `${Math.floor(s / 60)}m${String(Math.round(s % 60)).padStart(2, "0")}s`;
function reveal(p, select) {
  const plat = process.platform;
  // explorer parses its own command line: /select,"C:\a b\c.mp4" must reach it exactly like that.
  if (plat === "win32") spawn("explorer.exe", [select ? `/select,"${p}"` : `"${p}"`], { detached: true, stdio: "ignore", windowsVerbatimArguments: true }).unref();
  else if (plat === "darwin") spawn("open", select ? ["-R", p] : [p], { detached: true, stdio: "ignore" }).unref();
  else spawn("xdg-open", [select ? path.dirname(p) : p], { detached: true, stdio: "ignore" }).unref();
}

let PORT = Number(args.port || settings.port || 47821);
const server = http.createServer(async (req, res) => {
  try {
    const host = String(req.headers.host || "");
    if (!/^(127\.0\.0\.1|localhost)(:\d+)?$/.test(host)) return send(res, 403, { error: "bad host" });
    const url = new URL(req.url, `http://${host}`);
    if (req.method === "GET" && (url.pathname === "/" || url.pathname === "/index.html")) {
      let html;
      try { html = fs.readFileSync(path.join(here, "NFP-Archive.html"), "utf8"); }
      catch { res.writeHead(500); return res.end("NFP-Archive.html not found: run node build.mjs"); }
      if (!args.lite) html = html.replace('<meta name="nfp-helper-token" content="">', `<meta name="nfp-helper-token" content="${TOKEN}">`);
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store", "X-Frame-Options": "DENY" });
      return res.end(html);
    }
    if (url.pathname === "/health") return send(res, 200, { app: "nfp-archive", version: VERSION });
    if (!url.pathname.startsWith("/api/")) { res.writeHead(404); return res.end(); }
    const tok = String(req.headers["x-nfp-token"] || "");
    if (args.lite || tok.length !== TOKEN.length || !crypto.timingSafeEqual(Buffer.from(tok), Buffer.from(TOKEN))) return send(res, 401, { error: "token" });
    const p = url.pathname;
    if (req.method === "GET" && p === "/api/ping") return send(res, 200, { ok: true, version: VERSION, ffmpeg: hasFfmpeg, settings: publicSettings(), sources: Object.keys(NF.SOURCES).filter((id) => NF.enabled(id)) });
    if (req.method === "GET" && p === "/api/jobs") return send(res, 200, { jobs: jobs.slice().reverse().map(view) });
    if (req.method !== "POST") return send(res, 405, { error: "method" });
    const b = await body(req);
    if (p === "/api/settings") {
      if (b.dir) settings.dir = path.resolve(String(b.dir));
      if (b.connections) settings.connections = Math.max(1, Math.min(16, Math.round(Number(b.connections)) || 8));
      if (typeof b.proxy === "string") {
        if (b.proxy && !/^http:\/\/[\w.-]+:\d+\/?$/.test(b.proxy)) return send(res, 400, { error: "proxy must look like http://127.0.0.1:8080" });
        settings.proxy = b.proxy.replace(/\/$/, "");
      }
      if (b.keys && typeof b.keys === "object") {
        settings.keys = settings.keys || {};
        for (const k of KEYS) {
          if (typeof b.keys[k] !== "string") continue;
          const v = b.keys[k].trim();
          if (!v) delete settings.keys[k];
          else if (/^[\w.\-]{8,200}$/.test(v)) settings.keys[k] = v;
          else return send(res, 400, { error: `${k} doesn't look like a key` });
        }
        useKeys();
      }
      fs.mkdirSync(settings.dir, { recursive: true });
      saveSettings();
      return send(res, 200, { settings: publicSettings(), sources: Object.keys(NF.SOURCES).filter((id) => NF.enabled(id)) });
    }
    if (p === "/api/nf/search") {
      const q = String(b.q || "").replace(/\s+/g, " ").trim().slice(0, 200);
      if (!q) return send(res, 400, { error: "empty search" });
      const sources = [].concat(b.sources || []).filter((id) => NF.SOURCES[id]);
      const kind = b.kind === "image" || b.kind === "video" ? b.kind : undefined;
      const allow = [].concat(b.allow || ["free", "credit"]).filter((v) => /^(free|credit|careful)$/.test(v));
      const r = await NF.searchAll(q, { kind, sources, allow, page: Math.max(1, Math.min(50, Math.round(Number(b.page)) || 1)), per: Math.max(4, Math.min(40, Math.round(Number(b.per)) || 24)) });
      for (const it of r.items) remember(it);
      return send(res, 200, { items: r.items, errors: r.errors });
    }
    if (p === "/api/nf/details") {
      const it = b.it && typeof b.it === "object" ? b.it : null;
      if (!it || !NF.SOURCES[it.source]) return send(res, 400, { error: "bad item" });
      // NASA's file list lives at an address the search gave; never fetch one the page made up
      if (it.source === "nasa" && !/^https:\/\/images-assets\.nasa\.gov\//.test(String(it.collection || ""))) return send(res, 400, { error: "bad item" });
      const out = await NF.details(it);
      remember(out);
      return send(res, 200, { it: out });
    }
    if (p === "/api/download" || p === "/api/clip") {
      if (!allowedUrl(b.url)) return send(res, 400, { error: "not a link from the search" });
      // Unsplash asks apps to report each download
      if (/^https:\/\/api\.unsplash\.com\/photos\/[\w-]+\/download/.test(String(b.track || "")) && NF.keys.UNSPLASH_ACCESS_KEY) nfFetch(b.track, { headers: { Authorization: `Client-ID ${NF.keys.UNSPLASH_ACCESS_KEY}` } }).catch(() => {});
      const sub = clean(b.id || "misc", 80);
      const base = clean(path.basename(String(b.name || new URL(b.url).pathname)), 140);
      const clip = p === "/api/clip";
      let start = 0, end = 0;
      if (clip) {
        start = Math.max(0, Number(b.start) || 0);
        end = Number(b.end) || 0;
        if (!(end > start) || end - start > 1800) return send(res, 400, { error: "clip must be 0 to 30 minutes" });
        if (!hasFfmpeg) return send(res, 400, { error: "ffmpeg not found" });
      }
      const name = clip ? `${path.parse(base).name}_${fmtClip(start)}-${fmtClip(end)}.mp4` : base;
      const dup = jobs.find((j) => j.url === b.url && j.kind === (clip ? "clip" : "file") && (!clip || (j.start === start && j.end === end)) && /queued|running|probing|paused/.test(j.status));
      if (dup) return send(res, 200, { job: view(dup) });
      const job = {
        id: newId(), kind: clip ? "clip" : "file", url: b.url, name: base, file: uniquePath(path.join(settings.dir, sub, name)),
        status: "queued", total: Number(b.size) || 0, done: 0, unit: "B", title: String(b.title || "").slice(0, 300), itemId: sub,
        licence: String(b.licence || "").slice(0, 300), page: /^https:\/\//.test(String(b.page || "")) ? String(b.page).slice(0, 400) : "", start, end, size: Number(b.size) || 0, len: Number(b.len) || 0, created: Date.now(),
      };
      jobs.push(job);
      saveJobs();
      pump();
      return send(res, 200, { job: view(job) });
    }
    const m = /^\/api\/jobs\/([a-f0-9]+)\/(pause|resume|cancel|remove|reveal)$/.exec(p);
    if (m) {
      const job = jobs.find((j) => j.id === m[1]);
      if (!job) return send(res, 404, { error: "no such job" });
      const op = m[2];
      if (op === "pause" && /queued|running|probing/.test(job.status)) stop(job, "paused");
      if (op === "resume" && /paused|error|canceled/.test(job.status)) { job.status = "queued"; job.error = ""; saveJobs(); pump(); }
      if (op === "cancel") {
        stop(job, "canceled");
        setTimeout(() => { for (const f of [job.file + ".part", job.file + ".part.json", job.file + ".src", job.file + ".src.part", job.file + ".src.part.json", job.file + ".tmp.mp4"]) fs.rmSync(f, { force: true }); }, 800);
      }
      if (op === "remove" && !/running|probing/.test(job.status)) { jobs = jobs.filter((j) => j !== job); saveJobs(); }
      if (op === "reveal" && fs.existsSync(job.file)) reveal(job.file, true);
      return send(res, 200, { ok: true });
    }
    if (p === "/api/open-dir") { fs.mkdirSync(settings.dir, { recursive: true }); reveal(settings.dir, false); return send(res, 200, { ok: true }); }
    return send(res, 404, { error: "unknown" });
  } catch (e) {
    send(res, 500, { error: String(e && e.message || e) });
  }
});

function openBrowser(u) {
  if (process.platform === "win32") spawn("cmd", ["/c", "start", "", u], { detached: true, stdio: "ignore", windowsHide: true }).unref();
  else spawn(process.platform === "darwin" ? "open" : "xdg-open", [u], { detached: true, stdio: "ignore" }).unref();
}
async function alreadyRunning(port) {
  return new Promise((resolve) => {
    const r = http.get({ host: "127.0.0.1", port, path: "/health", timeout: 1500 }, (res) => {
      let s = ""; res.on("data", (d) => (s += d)); res.on("end", () => { try { resolve(JSON.parse(s).app === "nfp-archive"); } catch { resolve(false); } });
    });
    r.on("error", () => resolve(false));
    r.on("timeout", () => { r.destroy(); resolve(false); });
  });
}

(async () => {
  hasFfmpeg = (await which(settings.ffmpeg)) && (await which(settings.ffprobe));
  for (let i = 0; i < 10; i++) {
    if (await alreadyRunning(PORT)) {
      console.log(`NFP Archive is already running: http://127.0.0.1:${PORT}/`);
      if (args.open) openBrowser(`http://127.0.0.1:${PORT}/`);
      return;
    }
    const ok = await new Promise((resolve) => {
      server.once("error", () => resolve(false));
      server.listen(PORT, "127.0.0.1", () => resolve(true));
    });
    if (ok) break;
    PORT++;
  }
  if (!server.listening) { console.error("no free port"); process.exit(1); }
  const u = `http://127.0.0.1:${PORT}/`;
  console.log(`NFP Archive ${VERSION}${args.lite ? " (lite)" : ""}  ->  ${u}`);
  console.log(`downloads: ${settings.dir}`);
  console.log(`ffmpeg: ${hasFfmpeg ? "found (clips on)" : "not found (clips off)"}${settings.proxy ? `   proxy: ${settings.proxy}` : ""}`);
  console.log("Keep this window open while you use the page. Close it to stop.");
  if (args.open) openBrowser(u);
  pump();
})();
