// NFP Archive — the page: routing, search, result grid, item drawer, basket, and the local helper (start.bat)
// for direct downloads and clips. Opened straight from disk it works without the helper (links only).
// Two kinds of search: archive.org with its own filters (core.js), and the other free sites (sources.js: Wikimedia
// Commons, NASA, Coverr, Mixkit, museums, Pexels/Pixabay/Unsplash) — the helper runs those, or the page alone runs
// the ones that allow it.
(function () {
  "use strict";
  const NA = window.NA;
  const ICONS = window.NA_ICONS || {};
  const COVERS = window.NA_COVERS || {};
  const TOKEN = (document.querySelector('meta[name="nfp-helper-token"]') || {}).content || "";
  const PAGE = 36;

  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  const ic = (n, cls = "") => (ICONS[n] || "").replace("<svg ", `<svg class="i ${cls}" aria-hidden="true" focusable="false" `);
  // Every value from archive.org goes through esc(); links an uploader can set (licence URL) must also be http(s),
  // or a "javascript:" URL would run in this page.
  const safeUrl = (u) => (/^https?:\/\//i.test(String(u || "").trim()) ? String(u).trim() : "");
  const fmtN = (n) => Number(n || 0).toLocaleString("en-US");
  const store = {
    get(k, d) { try { const v = localStorage.getItem("nfp-archive:" + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem("nfp-archive:" + k, JSON.stringify(v)); } catch {} },
  };
  const catById = (id) => NA.CATEGORIES.find((c) => c.id === id);
  const yearText = (d) => NA.yearOf(d) || "";

  // ------------------------------------------------------------------ the other free sources (sources.js)
  const NF = window.NF;
  // our verdicts → the page's licence colours and words
  const NF_LV = { free: "free", credit: "free", careful: "claimed", blocked: "restricted" };
  const NF_FA = { free: "آزاد", credit: "آزاد · ذکر نام", careful: "با احتیاط", blocked: "ممنوع" };
  const NF_WHY = {
    free: "آزاد است: استفاده‌ی تجاری و ادیت مجاز است و ذکر نام لازم نیست، هرچند ذکرش کار درستی است.",
    credit: "آزاد است، به شرط ذکر نام سازنده و مجوز در کپشن یا توضیحات ویدیو. متن آماده پایین همین صفحه است.",
    careful: "با احتیاط: یا CC BY-SA است (اثر تو هم باید همان مجوز را بگیرد)، یا مجوز را آپلودکننده ادعا کرده. برای کار مهم صفحه‌ی منبع را بخوان.",
    blocked: "برای استفاده‌ی تجاری آزاد نیست.",
  };
  const SRC_OPTS = [
    ["all", "همه‌ی منبع‌های آزاد"],
    ["archive", "آرشیو اینترنت · فیلترهای کامل"],
    ["commons", "ویکی‌مدیا"],
    ["nasa", "ناسا"],
    ["coverr", "Coverr · فوتیج امروزی"],
    ["mixkit", "Mixkit · فوتیج امروزی"],
    ["museums", "موزه‌ها: نقاشی و عکس قدیمی"],
    ["pexels", "Pexels"],
    ["pixabay", "Pixabay"],
    ["unsplash", "Unsplash"],
  ];
  const MUSEUMS = ["cleveland", "wellcome", "europeana"];
  const nfMode = () => S.filters.source !== "archive";
  // The helper searches every source it has (keys included); the page alone only the sites that allow it (CORS),
  // never the ones that need a key.
  const canSearch = (id) => (S.helper.on ? (S.helper.sources || []).includes(id) : !!(NF && NF.SOURCES[id] && NF.SOURCES[id].cors && NF.enabled(id)));
  function nfSources() {
    const s = S.filters.source;
    const ids = s === "all" ? Object.keys(NF.SOURCES) : s === "museums" ? MUSEUMS : [s];
    return ids.filter(canSearch);
  }
  const srcName = (id) => (NF.SOURCES[id] ? NF.SOURCES[id].name : id);
  // the English words for the other sites: the translated search, or a topic's main phrase
  function nfQuery() {
    const r = S.route;
    if (r.view === "search") return S.qx && S.qx.en ? S.qx.en.replace(/\b(AND|OR)\b|[()"]/g, " ").replace(/\s+/g, " ").trim() : "";
    if (r.view === "cat") {
      const cat = catById(r.cat);
      const tp = cat.topics.find((t) => t.id === r.topic) || cat.topics[0];
      if (!tp.t) return cat.en.split("&")[0].trim();
      const alts = tp.t.split(/\s+OR\s+/i).map((x) => x.replace(/"/g, "").trim()).filter(Boolean);
      return alts.find((a) => a.includes(" ")) || alts[0];
    }
    return "";
  }

  const S = {
    route: { view: "home" },
    filters: Object.assign({ type: "all", licence: "all", decade: "", sort: "popular", scope: "curated", source: "all", nflic: "safe" }, store.get("filters", {})),
    nfErrors: {}, nfMore: false,
    qx: null,
    results: [], total: 0, page: 1, loading: false, error: null, note: "", lastOpts: null, reqId: 0,
    basket: store.get("basket", []),
    helper: { on: false, ffmpeg: false, settings: null, jobs: [], sources: [] },
    detail: null,
    panel: null,
  };

  // ------------------------------------------------------------------ theme / toast
  const root = document.documentElement;
  root.dataset.theme = store.get("theme", "dark");
  function toast(msg, iconName = "check") {
    const el = document.createElement("div");
    el.className = "toast";
    el.innerHTML = `${ic(iconName)}<span>${esc(msg)}</span>`;
    $("#toasts").append(el);
    setTimeout(() => el.remove(), 2600);
  }
  async function copy(text, msg = "کپی شد") {
    try { await navigator.clipboard.writeText(text); }
    catch {
      const t = document.createElement("textarea");
      t.value = text; document.body.append(t); t.select();
      try { document.execCommand("copy"); } catch {}
      t.remove();
    }
    toast(msg, "copy");
  }

  // ------------------------------------------------------------------ routing
  function parseHash() {
    const raw = decodeURI(location.hash.replace(/^#/, "")) || "/";
    const [p, qs] = raw.split("?");
    const params = new URLSearchParams(qs || "");
    const parts = p.split("/").filter(Boolean);
    let r = { view: "home" };
    if (parts[0] === "c" && catById(parts[1])) r = { view: "cat", cat: parts[1], topic: parts[2] || null };
    else if (parts[0] === "s" && parts[1]) r = { view: "search", q: decodeURIComponent(parts.slice(1).join("/")) };
    r.item = params.get("i") || null;
    return r;
  }
  function viewHash(r) {
    if (r.view === "cat") return `#/c/${r.cat}/${r.topic || ""}`;
    if (r.view === "search") return `#/s/${encodeURIComponent(r.q)}`;
    return "#/";
  }
  const sameView = (a, b) => a.view === b.view && a.cat === b.cat && a.topic === b.topic && a.q === b.q;

  function onRoute() {
    const r = parseHash();
    const prev = S.route;
    S.route = r;
    if (!sameView(r, prev) || !$("#main").dataset.ready) {
      enterView(r);
      window.scrollTo({ top: 0 });
    }
    if (r.item !== (S.detail && S.detail.id)) r.item ? openDetail(r.item) : closeDetail(true);
  }
  function openItem(id) { location.hash = viewHash(S.route) + "?i=" + encodeURIComponent(id); }
  function closeItem() {
    if (!S.route.item) return closeDetail(true);
    history.length > 1 && S.cameFromGrid ? history.back() : (location.hash = viewHash(S.route));
  }

  function enterView(r) {
    const main = $("#main");
    main.dataset.ready = "1";
    if (r.view === "home") { $("#q").value = ""; renderHome(); return; }
    if (r.view === "cat") {
      const cat = catById(r.cat);
      const tp = cat.topics.find((t) => t.id === r.topic) || cat.topics[0];
      r.topic = tp.id;
      if (tp.type) S.filters.type = tp.type;
      if (cat.licence) S.filters.licence = cat.licence;
      $("#q").value = "";
    }
    if (r.view === "search") {
      S.qx = prepQuery(r.q);
      $("#q").value = r.q;
      if (S.qx.type) S.filters.type = S.qx.type;
      if (S.qx.decade) S.filters.decade = S.qx.decade;
    }
    renderShell();
    runSearch(false);
  }

  // ------------------------------------------------------------------ search
  function prepQuery(q) {
    const norm = NA.normFa(q);
    const hasFa = NA.hasPersian(q);
    const tr = hasFa ? NA.translate(q, NA.DICT) : { en: q.trim(), parts: [], unknown: [], decade: "", year: 0 };
    let type = "";
    if (hasFa && NA.MEDIA_FA.image.test(norm)) type = "image";
    else if (hasFa && NA.MEDIA_FA.movies.test(norm)) type = "movies";
    return Object.assign({ raw: q, hasFa, type }, tr);
  }

  function currentOpts() {
    const f = S.filters, r = S.route;
    const base = { scope: f.scope, type: f.type, licence: f.licence, decade: f.decade, sort: f.sort };
    if (r.view === "cat") {
      const cat = catById(r.cat);
      const tp = cat.topics.find((t) => t.id === r.topic) || cat.topics[0];
      return Object.assign(base, { clause: NA.topicClause(tp), fiction: !!cat.fiction });
    }
    if (r.view === "search") {
      if (!S.qx.en) return null;
      return Object.assign(base, { clause: { terms: NA.T(S.qx.en), cols: "", and: S.qx.year ? `year:${S.qx.year}` : "" }, fiction: true });
    }
    return null;
  }

  async function runSearch(append) {
    const id = ++S.reqId;
    if (!append) { S.page = 1; S.results = []; S.total = 0; S.error = null; S.note = ""; S.lastOpts = null; }
    S.loading = true;
    renderResults(append);
    try {
      if (nfMode()) {
        const q = nfQuery();
        if (!q) { S.loading = false; renderResults(false); return; }
        const f = S.filters;
        const sources = nfSources();
        const kind = f.type === "movies" ? "video" : f.type === "image" ? "image" : undefined;
        const allow = f.nflic === "wide" ? ["free", "credit", "careful"] : ["free", "credit"];
        const per = sources.length > 2 ? 8 : 24;
        const r = !sources.length ? { items: [], errors: {} }
          : S.helper.on ? await api("/api/nf/search", { q, kind, sources, page: S.page, per, allow })
          : await NF.searchAll(q, { kind, sources, page: S.page, per, allow });
        if (id !== S.reqId) return;
        const fresh = r.items.map((it) => Object.assign(it, { _k: it.source + ":" + it.id })).filter((it) => !S.results.some((x) => x._k === it._k));
        // the ones whose title says what was asked first; otherwise keep the mix of sites
        const words = q.toLowerCase().split(/\s+/).filter((w) => w.length > 2).map((w) => w.replace(/s$/, ""));
        const score = (it) => { const t = `${it.title} ${it.desc || ""}`.toLowerCase(); return words.length ? words.filter((w) => t.includes(w)).length / words.length : 0; };
        fresh.forEach((it, i) => { it._o = i; it._s = score(it); });
        fresh.sort((a, b) => b._s - a._s || a._o - b._o);
        S.results = S.results.concat(fresh);
        S.nfErrors = r.errors || {};
        S.nfMore = fresh.length > 0 && r.items.length >= per;
        S.total = S.results.length;
        S.loading = false;
        renderResults(append, fresh);
        return;
      }
      let opts = append ? S.lastOpts : currentOpts();
      if (!opts) { S.loading = false; renderResults(false); return; }
      let r = await NA.search(opts, S.page, PAGE);
      // A thin search widens itself step by step: without the year (footage about 1929 is rarely dated 1929),
      // then any of the words, then the descriptions too.
      if (!append && S.route.view === "search" && r.total < 8) {
        const anyWords = S.qx.en.replace(/ AND /g, " OR ");
        const steps = [
          ["year", (o) => (o.clause.and ? Object.assign({}, o, { clause: Object.assign({}, o.clause, { and: "" }) }) : null)],
          ["any", (o) => (anyWords !== S.qx.en ? Object.assign({}, o, { clause: Object.assign({}, o.clause, { terms: NA.T(anyWords) }) }) : null)],
          ["text", (o) => Object.assign({}, o, { clause: Object.assign({}, o.clause, { terms: `(${anyWords})` }) })],
        ];
        // the steps add up: the description search also goes without the year
        let cur = opts;
        const applied = [];
        for (const [name, widen] of steps) {
          if (r.total >= 8) break;
          const o2 = widen(cur);
          if (!o2) continue;
          cur = o2;
          applied.push(name);
          const r2 = await NA.search(o2, 1, PAGE);
          if (r2.total > r.total) { r = r2; opts = o2; S.note = applied.join(" "); }
        }
      }
      if (id !== S.reqId) return;
      S.lastOpts = opts;
      S.total = r.total;
      const fresh = r.docs.filter((d) => !S.results.some((x) => x.identifier === d.identifier));
      S.results = S.results.concat(fresh);
      S.loading = false;
      renderResults(append, fresh);
    } catch (e) {
      if (id !== S.reqId) return;
      S.loading = false;
      S.error = e;
      renderResults(false);
    }
  }
  function setFilter(k, v) {
    S.filters[k] = v;
    store.set("filters", { type: S.filters.type, licence: S.filters.licence, decade: S.filters.decade, sort: S.filters.sort, scope: S.filters.scope, source: S.filters.source, nflic: S.filters.nflic });
    renderFilters();
    runSearch(false);
  }

  // ------------------------------------------------------------------ home
  const SUGGEST = ["فرود روی ماه", "city traffic at night", "تبلیغات دهه‌ی ۵۰", "ocean waves", "شاهنامه", "سقوط بازار ۱۹۲۹", "تهران", "rocket launch", "کامپیوترهای قدیمی", "Hindenburg"];
  const WIDE = new Set(["space", "iran"]);
  function renderHome() {
    const cats = NA.CATEGORIES.filter((c) => c.id !== "free");
    const free = catById("free");
    $("#main").innerHTML = `
      ${S.helper.on ? "" : liteNote()}
      <section class="hero">
        <h1>فیلم و عکس آزاد برای <em>ویدیوهات</em></h1>
        <p>در آرشیو اینترنت، ویکی‌مدیا، ناسا، Coverr، Mixkit و موزه‌ها بگرد؛ از نیوزریل قدیمی تا فوتیج رنگی امروزی. مجوز هر فایل را ببین و ${S.helper.on ? "مستقیم دانلود کن یا فقط تکه‌ی لازم را ببُر." : "لینک مستقیم دانلود بگیر."}</p>
        <div class="suggest">${SUGGEST.map((s) => `<button class="chip" data-act="suggest" data-q="${esc(s)}">${ic("magnifying-glass")}${esc(s)}</button>`).join("")}</div>
      </section>
      <section class="cats" aria-label="دسته‌بندی‌ها">
        ${cats.map((c, k) => `
          <button class="cat ${WIDE.has(c.id) ? "wide" : ""}" data-act="cat" data-cat="${c.id}" style="--k:${k}">
            ${COVERS[c.id] ? `<img src="${COVERS[c.id]}" alt="" loading="lazy">` : ""}
            <span class="cat-in">${ic(ICON_OF[c.icon] || "folder-open")}<h3>${esc(c.fa)}</h3><small>${esc(c.en)}</small></span>
            <span class="topics-n">${c.topics.length} موضوع</span>
          </button>`).join("")}
      </section>
      <section class="free-band">
        <div>
          <h3>${ic("shield-check")}${esc(free.fa)}</h3>
          <p>این منابع برای استفاده‌ی تجاری هم آزادند: ساخته‌ی دولت آمریکا، نیوزریل‌هایی که به مالکیت عمومی داده شده، و آثار قبل از ۱۹۳۱.</p>
        </div>
        <div class="chips">${free.topics.map((t) => `<button class="chip" data-act="go" data-href="#/c/free/${t.id}">${esc(t.fa)}</button>`).join("")}</div>
      </section>
      ${licenceGuide()}`;
  }
  const ICON_OF = { rocket: "rocket-launch", helmet: "sword", dome: "mosque", chip: "cpu", atom: "atom", leaf: "leaf", city: "buildings", plane: "airplane-tilt", gear: "factory", coin: "coins", tv: "television", film: "film-slate", ball: "soccer-ball", shield: "shield-check", frame: "paint-brush-broad" };

  function liteNote() {
    return `<div class="lite-note">${ic("info")}<span>بدون برنامه‌ی کمکی باز شده: لینک‌ها را با مرورگر یا IDM بگیر. برای دانلود سریع چندبخشی، بریدن فقط تکه‌ی لازم، و منبع‌های Coverr، Mixkit، Pexels، Pixabay و Unsplash، با <b class="lat">start.bat</b> اجرا کن.</span></div>`;
  }
  function licenceGuide() {
    const row = (lv, title, text) => `<div><h4><span class="lic lic-${lv}">${esc(NA.LEVELS[lv].fa)}</span></h4><p>${text}</p></div>`;
    return `<section class="guide" aria-label="راهنمای مجوزها">
      ${row("free", "", "ساخته‌ی دولت آمریکا، نیوزریل‌های Universal، موزه‌ها و آرشیوهایی که خودشان آزاد اعلام کرده‌اند، یا آثار قبل از ۱۹۳۱. برای کانال درآمددار هم آزاد است.")}
      ${row("claimed", "", "مجوز را خود آپلودکننده گذاشته. فقط اگر صاحب اثر باشد معتبر است؛ برای کار مهم منبع اصلی را چک کن.")}
      ${row("restricted", "", "مجوز غیرتجاری یا «بدون تغییر». برای پیجی که درآمد دارد یا ادیت روی آن، مناسب نیست.")}
      ${row("unknown", "", "مجوزی ثبت نشده (تبلیغ برندها، تلویزیون، فیلم). فقط تکه‌ی کوتاه با روایت خودت و بدون موزیک اصلی؛ ممکن است Content ID بخورد.")}
    </section>`;
  }

  // ------------------------------------------------------------------ results view
  function renderShell() {
    const r = S.route;
    let head = "";
    if (r.view === "cat") {
      const cat = catById(r.cat);
      head = `
        <nav class="crumbs"><a href="#/">خانه</a>${ic("caret-left")}<span>${esc(cat.en)}</span></nav>
        <h2>${esc(cat.fa)}</h2>
        <div class="topics" role="tablist">${cat.topics.map((t) => `<button class="chip" role="tab" aria-pressed="${t.id === r.topic}" data-act="go" data-href="#/c/${cat.id}/${t.id}">${esc(t.fa)}</button>`).join("")}</div>`;
    } else {
      head = `
        <nav class="crumbs"><a href="#/">خانه</a>${ic("caret-left")}<span>جستجو</span></nav>
        <h2>${esc(r.q)}</h2>
        <div class="qinfo" id="qinfo"></div>`;
    }
    $("#main").innerHTML = `
      ${S.helper.on ? "" : liteNote()}
      <section class="view-head">${head}</section>
      <div class="filters" id="filters"></div>
      <section id="results" aria-live="polite"></section>`;
    renderFilters();
    if (r.view === "search") renderQInfo();
  }
  function renderQInfo() {
    const el = $("#qinfo");
    if (!el || !S.qx) return;
    const q = S.qx;
    const bits = [];
    if (q.hasFa && q.en) bits.push(`<span>جستجو به انگلیسی:</span><code>${esc(q.en)}</code>`);
    if (q.year) bits.push(`<span>سال <b class="num">${q.year}</b></span>`);
    if (q.unknown.length) bits.push(`<span class="warn">${ic("warning")} این کلمه‌ها را نشناختم: ${esc(q.unknown.join("، "))}. برای نتیجه‌ی بهتر انگلیسی‌شان را بنویس.</span>`);
    const notes = (S.note || "").split(" ");
    if (notes.includes("year")) bits.push(`<span>${ic("info")} با سال ${q.year} کم بود؛ همه‌ی سال‌ها را گشتم.</span>`);
    if (notes.includes("any")) bits.push(`<span>${ic("info")} هر کدام از کلمه‌ها را جدا هم گشتم.</span>`);
    if (notes.includes("text")) bits.push(`<span>${ic("info")} در توضیحات فایل‌ها هم گشتم.</span>`);
    el.innerHTML = bits.join("");
  }
  function renderFilters() {
    const f = S.filters, el = $("#filters");
    if (!el) return;
    const seg = (key, opts) => `<div class="seg" role="group">${opts.map(([v, label, icon]) => `<button aria-pressed="${f[key] === v}" data-act="filter" data-k="${key}" data-v="${v}">${icon ? ic(icon) : ""}${label}</button>`).join("")}</div>`;
    const why = (v) => {
      const s = NF.SOURCES[v];
      return s && s.key && !s.optionalKey ? " (کلید لازم، با start.bat)" : " (با start.bat)";
    };
    const srcSel = `<select class="select" data-act="filter-sel" data-k="source" aria-label="منبع">${SRC_OPTS.map(([v, label]) => {
      const ok = v === "all" || v === "archive" || (v === "museums" ? MUSEUMS.some(canSearch) : canSearch(v));
      return `<option value="${v}" ${f.source === v ? "selected" : ""} ${ok ? "" : "disabled"}>${esc(label + (ok ? "" : why(v)))}</option>`;
    }).join("")}</select>`;
    if (nfMode()) {
      el.innerHTML = `
        ${srcSel}
        ${seg("type", [["all", "همه"], ["movies", "ویدیو", "film-strip"], ["image", "عکس", "image"]])}
        ${seg("nflic", [["safe", "آزاد و ذکر نام", "shield-check"], ["wide", "+ با احتیاط"]])}
        <span class="sep"></span>
        <span class="total" id="total"></span>`;
      return;
    }
    el.innerHTML = `
      ${srcSel}
      ${seg("type", [["all", "همه"], ["movies", "ویدیو", "film-strip"], ["image", "عکس", "image"]])}
      ${seg("licence", [["all", "همه‌ی مجوزها"], ["free", "آزاد", "shield-check"], ["open", "آزاد و ادعایی"]])}
      <select class="select" data-act="filter-sel" data-k="decade" aria-label="دهه">
        <option value="">همه‌ی سال‌ها</option>
        ${NA.DECADES.map((d) => `<option value="${d.id}" ${f.decade === d.id ? "selected" : ""}>${esc(d.fa)}</option>`).join("")}
      </select>
      <select class="select" data-act="filter-sel" data-k="sort" aria-label="ترتیب">
        ${NA.SORTS.map((s) => `<option value="${s.id}" ${f.sort === s.id ? "selected" : ""}>${esc(s.fa)}</option>`).join("")}
      </select>
      ${seg("scope", [["curated", "آرشیوهای معتبر"], ["all", "کل آرشیو", "globe"]])}
      <span class="sep"></span>
      <span class="total" id="total"></span>`;
  }

  function cardHtml(d, k) {
    const v = NA.verdict(d);
    const isImg = d.mediatype === "image";
    const inB = S.basket.some((b) => b.id === d.identifier);
    return `<article class="card" tabindex="0" role="button" data-act="item" data-id="${esc(d.identifier)}" style="--k:${k % 18}">
      <div class="thumb">
        <img src="${NA.thumb(d.identifier)}" alt="" loading="lazy" onload="this.classList.add('ok')" onerror="this.remove()">
        <span class="kind">${ic(isImg ? "image" : "film-strip")}</span>
        ${inB ? `<span class="in-basket" title="در سبد">${ic("check")}</span>` : ""}
        <span class="tag" data-tag hidden></span>
      </div>
      <h3 dir="ltr">${esc(d.title || d.identifier)}</h3>
      <div class="meta"><span class="lic lic-${v.level}">${esc(NA.LEVELS[v.level].short)}</span>${yearText(d) ? `<span class="num">${yearText(d)}</span>` : ""}<span class="num">${fmtN(d.downloads)} ${ic("download-simple")}</span></div>
    </article>`;
  }
  function skeletons(n) {
    return Array.from({ length: n }, () => `<div class="sk-card" aria-hidden="true"><div class="sk a"></div><div class="sk b"></div><div class="sk c"></div></div>`).join("");
  }

  function renderResults(append, fresh = []) {
    const el = $("#results");
    if (!el) return;
    renderQInfo();
    const tot = $("#total");
    if (tot) tot.innerHTML = nfMode() ? (S.results.length ? `<span class="num">${fmtN(S.results.length)}</span> نتیجه` : "") + nfErrNote() : S.total ? `<span class="num">${fmtN(S.results.length)}</span> از <span class="num">${fmtN(S.total)}</span> نتیجه` : "";
    if (S.error) {
      el.innerHTML = `<div class="state">${ic("warning", "big")}<h3>به آرشیو وصل نشد</h3><p>اینترنت یا فیلترشکن را چک کن و دوباره بزن. اگر از ایران وصل نمی‌شود، یک‌بار با فیلترشکن امتحان کن.</p><div class="row"><button class="btn primary" data-act="retry">${ic("arrow-clockwise")}دوباره</button></div></div>`;
      return;
    }
    if (S.route.view === "search" && S.qx && !S.qx.en) {
      el.innerHTML = `<div class="state">${ic("translate", "big")}<h3>این جستجو را نتوانستم به انگلیسی برگردانم</h3><p>آرشیو انگلیسی است. کلمه‌ی کلیدی را انگلیسی بنویس، مثلاً <span class="lat">moon landing</span> یا <span class="lat">tehran</span>.</p></div>`;
      return;
    }
    if (append) {
      const grid = $("#grid");
      $("#more") && $("#more").remove();
      if (S.loading) { grid.insertAdjacentHTML("beforeend", `<div id="skmore" style="display:contents">${skeletons(8)}</div>`); return; }
      $("#skmore") && $("#skmore").remove();
      grid.insertAdjacentHTML("beforeend", fresh.map((d, k) => (d._k ? nfCardHtml(d, k) : cardHtml(d, k))).join(""));
      observeCards();
      moreButton(el);
      return;
    }
    if (S.loading) { el.innerHTML = `<div class="grid">${skeletons(18)}</div>`; return; }
    if (!S.results.length && nfMode()) {
      const errs = Object.entries(S.nfErrors || {}).map(([k, e]) => `<span class="en">${esc(srcName(k))}: ${esc(e)}</span>`).join("<br>");
      const none = !nfSources().length;
      el.innerHTML = `<div class="state">${ic("magnifying-glass", "big")}<h3>${none ? "این منبع از اینجا در دسترس نیست" : "چیزی پیدا نشد"}</h3><p>${none ? "برای این منبع برنامه‌ی کمکی (start.bat) یا کلید رایگانش لازم است." : "کلمه‌ی کلی‌تر یا انگلیسی بنویس، «همه‌ی منبع‌های آزاد» را انتخاب کن، یا «+ با احتیاط» را بزن."}</p>${errs ? `<p style="font-size:12.5px">${errs}</p>` : ""}${S.filters.source !== "all" ? `<div class="row"><button class="btn ghost" data-act="filter" data-k="source" data-v="all">${ic("globe")}همه‌ی منبع‌ها</button></div>` : ""}</div>`;
      return;
    }
    if (!S.results.length) {
      const scopeHint = S.filters.scope === "curated" ? `<button class="btn ghost" data-act="filter" data-k="scope" data-v="all">${ic("globe")}گشتن در کل آرشیو</button>` : "";
      const filt = S.filters.licence !== "all" || S.filters.decade || S.filters.type !== "all";
      el.innerHTML = `<div class="state">${ic("magnifying-glass", "big")}<h3>چیزی پیدا نشد</h3><p>فیلترها را کمتر کن، کلمه‌ی کلی‌تری بنویس یا انگلیسی جستجو کن.</p><div class="row">${filt ? `<button class="btn ghost" data-act="reset-filters">${ic("funnel")}برداشتن فیلترها</button>` : ""}${scopeHint}</div></div>`;
      return;
    }
    el.innerHTML = `<div class="grid" id="grid">${S.results.map((d, k) => (d._k ? nfCardHtml(d, k) : cardHtml(d, k))).join("")}</div>`;
    observeCards();
    moreButton(el);
  }
  // sites that didn't answer this time (a missing key is not news: the source list already says so)
  function nfErrNote() {
    const e = Object.keys(S.nfErrors || {}).filter((k) => !/^needs /.test(S.nfErrors[k]));
    if (!e.length || S.loading) return "";
    return ` <span class="warn" title="${esc(e.map((k) => `${srcName(k)}: ${S.nfErrors[k]}`).join(" · "))}">· ${esc(e.map(srcName).join("، "))} جواب نداد${S.helper.on ? "؛ اگر از ایران است، پراکسی را در تنظیمات بگذار" : ""}</span>`;
  }
  function moreButton(el) {
    if (nfMode() ? S.nfMore : S.results.length < S.total) el.insertAdjacentHTML("beforeend", `<div class="more" id="more"><button class="btn ghost" data-act="more">نتایج بیشتر</button></div>`);
  }

  // Card details (length, resolution, size) come from each item's file list, fetched only when the card is seen.
  const metaQueue = [];
  let metaBusy = 0;
  const io = "IntersectionObserver" in window ? new IntersectionObserver((ents) => {
    for (const e of ents) if (e.isIntersecting) { io.unobserve(e.target); metaQueue.push(e.target); }
    pumpMeta();
  }, { rootMargin: "200px" }) : null;
  function observeCards() { if (io) document.querySelectorAll(".card[data-id]:not([data-seen])").forEach((c) => { c.dataset.seen = "1"; io.observe(c); }); }
  function pumpMeta() {
    while (metaBusy < 4 && metaQueue.length) {
      const card = metaQueue.shift();
      metaBusy++;
      NA.metadata(card.dataset.id).then((m) => fillCard(card, m)).catch(() => {}).finally(() => { metaBusy--; pumpMeta(); });
    }
  }
  function fillCard(card, meta) {
    const f = NA.pickFiles(meta);
    const tag = card.querySelector("[data-tag]");
    if (!tag) return;
    if (f.videos.length) {
      const v = f.videos[0];
      const q = NA.quality(v.h);
      tag.innerHTML = `${v.len ? NA.fmtTime(v.len) : ""}${q ? ` ${q}` : ""}${f.videos.length > 1 ? ` ×${f.videos.length}` : ""}`;
      tag.hidden = !tag.textContent.trim();
    } else if (f.images.length) {
      tag.innerHTML = `${ic("images")}${f.images.length}`;
      tag.hidden = false;
    } else {
      card.classList.add("nofile");
      tag.innerHTML = "بدون فایل";
      tag.hidden = false;
    }
  }

  // ------------------------------------------------------------------ item drawer
  async function openDetail(id) {
    S.detail = { id, meta: null, files: null, cur: 0, img: 0, clip: { a: 0, b: 0 } };
    const d = $("#drawer");
    d.innerHTML = `<div class="d-head"><h2>…</h2><button class="btn icon ghost" data-act="close-item" aria-label="بستن">${ic("x")}</button></div>
      <div class="d-body"><div class="media sk"></div><div class="sk" style="height:22px;width:70%;margin:20px 0 0 auto;border-radius:999px"></div><div class="sk" style="height:90px;margin-top:18px"></div></div>`;
    showLayer("drawer");
    try {
      const meta = await NA.metadata(id);
      if (!S.detail || S.detail.id !== id) return;
      if (!meta || !meta.metadata) throw new Error("not found");
      S.detail.meta = meta;
      S.detail.files = NA.pickFiles(meta);
      renderDetail();
    } catch (e) {
      if (!S.detail || S.detail.id !== id) return;
      $("#drawer .d-body").innerHTML = `<div class="state">${ic("warning", "big")}<h3>اطلاعات این مورد نیامد</h3><p>شاید اینترنت قطع شد یا این مورد از آرشیو برداشته شده.</p><div class="row"><button class="btn primary" data-act="item" data-id="${esc(id)}">${ic("arrow-clockwise")}دوباره</button><a class="btn ghost" href="${NA.itemUrl(id)}" target="_blank" rel="noopener">${ic("arrow-square-out")}صفحه‌ی آرشیو</a></div></div>`;
    }
  }
  function closeDetail(silent) {
    S.detail = null;
    hideLayer("drawer");
    const v = $("#drawer video");
    if (v) v.pause();
    if (!silent && S.route.item) closeItem();
  }

  function descText(html) {
    if (!html) return "";
    const s = Array.isArray(html) ? html.join("\n") : String(html);
    const doc = new DOMParser().parseFromString(s.replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>/gi, "\n\n"), "text/html");
    return (doc.body.textContent || "").replace(/\n{3,}/g, "\n\n").trim();
  }
  const colNames = (c) => [].concat(c || []).filter((x) => !/^fav-/.test(x));

  function creditText(m, v) {
    const y = NA.yearOf(m);
    return `${m.title || m.identifier}${y ? ` (${y})` : ""}\nSource: Internet Archive, ${NA.itemUrl(m.identifier)}\n${NA.CREDIT_EN[v.why] || ""}`;
  }

  function renderDetail() {
    const D = S.detail, meta = D.meta, m = meta.metadata, f = D.files;
    const v = NA.verdict(Object.assign({}, m, { identifier: m.identifier }));
    const isImg = !f.videos.length && f.images.length;
    const inB = S.basket.some((b) => b.id === m.identifier);
    const vid = f.videos[D.cur];
    let media = "";
    if (vid) {
      media = vid.preview
        ? `<div class="media"><video id="player" controls preload="metadata" playsinline ${vid.poster ? `poster="${vid.poster}"` : ""} src="${vid.preview}"></video></div>`
        : `<div class="media">${vid.poster ? `<img src="${vid.poster}" alt="">` : `<div class="noprev">${ic("monitor-play", "big")}پیش‌نمایش ندارد؛ فایل را دانلود کن</div>`}</div>`;
    } else if (isImg) {
      const im = f.images[D.img];
      media = `<div class="media"><img src="${esc(im.preview || im.thumb || "")}" data-fallback="${esc(im.thumb || NA.thumb(m.identifier))}" alt="${esc(m.title)}"></div>
        ${f.images.length > 1 ? `<div class="gallery">${f.images.slice(0, 60).map((x, i) => `<button aria-pressed="${i === D.img}" data-act="pick-img" data-i="${i}"><img src="${esc(x.thumb || x.preview)}" alt="" loading="lazy"></button>`).join("")}</div>` : ""}`;
    } else {
      media = `<div class="media"><img src="${NA.thumb(m.identifier)}" alt=""></div>`;
    }
    const cols = colNames(m.collection);
    const helperClip = S.helper.on && S.helper.ffmpeg && vid;
    const desc = descText(m.description);
    $("#drawer").innerHTML = `
      <div class="d-head">
        <h2>${isImg ? "عکس" : vid ? "ویدیو" : "مورد"}</h2>
        <a class="btn sm ghost" href="${NA.itemUrl(m.identifier)}" target="_blank" rel="noopener">${ic("arrow-square-out")}archive.org</a>
        <button class="btn icon ghost" data-act="close-item" aria-label="بستن">${ic("x")}</button>
      </div>
      <div class="d-body">
        ${media}
        <h1 class="d-title" dir="ltr">${esc(m.title || m.identifier)}</h1>
        <div class="d-meta">
          ${NA.yearOf(m) ? `<span>سال <b class="num">${NA.yearOf(m)}</b></span>` : ""}
          ${m.creator ? `<span class="en">${esc([].concat(m.creator).join(", "))}</span>` : ""}
          ${cols.length ? `<span class="en">${esc(cols.slice(0, 3).join(" / "))}</span>` : ""}
        </div>
        <div class="licbox" style="--c:var(--${v.level === "free" ? "free" : v.level === "claimed" ? "claimed" : v.level === "restricted" ? "restricted" : "unknown"})">
          <span class="lic lic-${v.level}">${esc(NA.LEVELS[v.level].fa)}</span>
          <p>${esc(NA.WHY[v.why] || "")}</p>
          ${safeUrl(v.lic) ? `<a class="en" href="${esc(safeUrl(v.lic))}" target="_blank" rel="noopener noreferrer">${esc(v.lic.replace(/^https?:\/\//, ""))}</a>` : v.lic ? `<span class="en">${esc(v.lic)}</span>` : ""}
          ${m.rights ? `<p class="en" style="direction:ltr;text-align:left">${esc(descText(m.rights)).slice(0, 400)}</p>` : ""}
        </div>
        <div class="acts">
          <button class="btn ${inB ? "ghost" : "primary"}" data-act="basket-toggle">${ic(inB ? "check" : "basket")}${inB ? "در سبد است" : "افزودن به سبد"}</button>
          <button class="btn ghost" data-act="copy-credit">${ic("copy")}کپی منبع برای توضیحات</button>
        </div>
        ${vid ? videoFiles(f, D.cur, helperClip) : ""}
        ${isImg ? imageFiles(f) : ""}
        ${!vid && !isImg ? `<div class="state" style="padding:30px 10px"><p>این مورد فایل ویدیو یا عکس ندارد.</p>${f.pdfs.length ? `<div class="row">${f.pdfs.slice(0, 3).map((p) => `<a class="btn ghost" href="${p.url}" target="_blank" rel="noopener">${ic("file-text")}<span class="en">${esc(p.name)}</span></a>`).join("")}</div>` : ""}</div>` : ""}
        <div class="credit"><h3 class="sec-t">${ic("file-text")}منبع (برای توضیحات ویدیو)</h3><pre>${esc(creditText(m, v))}</pre></div>
        ${desc ? `<h3 class="sec-t">${ic("info")}توضیحات آرشیو</h3><div class="desc" dir="ltr">${esc(desc.slice(0, 4000))}</div>` : ""}
      </div>`;
    if (helperClip) bindClip();
    // A big image's IIIF render can fail (504); fall back to archive.org's small thumbnail.
    $("#drawer").querySelectorAll("img[data-fallback]").forEach((img) => img.addEventListener("error", () => {
      if (img.src !== img.dataset.fallback) img.src = img.dataset.fallback;
    }, { once: true }));
  }

  function fileRow(x, i, opt = {}) {
    const q = NA.quality(x.h);
    const meta = [x.w ? `<span class="num">${x.w}×${x.h}</span>` : "", q ? `<span>${q}</span>` : "", x.len ? `<span class="num">${NA.fmtTime(x.len)}</span>` : "", x.size ? `<span class="num">${NA.fmtSize(x.size)}</span>` : "", x.format ? `<span class="en">${esc(x.format)}</span>` : ""].filter(Boolean).join("");
    return `<div class="file ${opt.alt ? "alt" : ""}">
      <div class="fn" title="${esc(x.name)}">${esc(x.name)}</div>
      <div class="fa">
        ${opt.play ? `<button class="btn icon sm ghost" data-act="play" data-i="${i}" aria-label="پخش">${ic("play")}</button>` : ""}
        <button class="btn icon sm ghost" data-act="copy-link" data-url="${esc(x.url)}" aria-label="کپی لینک">${ic("link")}</button>
        ${dlButton(x)}
      </div>
      <div class="fm">${meta}${opt.note ? `<span>${opt.note}</span>` : ""}</div>
    </div>`;
  }
  function dlButton(x) {
    if (S.helper.on) return `<button class="btn sm primary" data-act="dl" data-url="${esc(x.url)}" data-name="${esc(x.name)}" data-size="${x.size || 0}">${ic("download-simple")}دانلود</button>`;
    return `<a class="btn sm primary" href="${esc(x.url)}" download target="_blank" rel="noopener">${ic("download-simple")}دانلود</a>`;
  }
  function videoFiles(f, cur, helperClip) {
    const vid = f.videos[cur];
    const big = vid.size > 1.5e9;
    let h = `<h3 class="sec-t">${ic("film-strip")}${f.videos.length > 1 ? `فایل‌ها (${f.videos.length})` : "فایل اصلی"}</h3>`;
    if (helperClip) {
      h += `<div class="clip" id="clipbox">
        <div class="row"><b>${ic("scissors")} فقط یک تکه از این ویدیو</b></div>
        <div class="row">
          <button class="btn sm ghost" data-act="clip-a">شروع = همین لحظه</button><input id="clipA" value="0:00" inputmode="numeric" aria-label="شروع">
          <button class="btn sm ghost" data-act="clip-b">پایان = همین لحظه</button><input id="clipB" value="0:10" inputmode="numeric" aria-label="پایان">
          <span class="len" id="clipLen"></span>
        </div>
        <div class="row"><button class="btn primary" data-act="clip">${ic("scissors")}بریدن و دانلود</button></div>
        <p>از فایل اصلی (بهترین کیفیت) بریده می‌شود و MP4 تحویل می‌گیری؛ فیلم‌های قدیمی خودکار دی‌اینترلیس می‌شوند.</p>
      </div>`;
    } else if (big && !S.helper.on) {
      h += `<p class="field"><small>${ic("info")} این فایل حجیم است. با اجرای start.bat می‌توانی فقط تکه‌ی لازم را ببُری.</small></p>`;
    }
    h += `<div class="files" style="margin-top:12px">`;
    f.videos.slice(0, 40).forEach((x, i) => {
      h += fileRow(x, i, { play: f.videos.length > 1 && x.preview, note: i === cur && f.videos.length > 1 ? "در حال پخش" : x.original ? "" : "نسخه‌ی تبدیل‌شده" });
    });
    if (f.videos.length > 40) h += `<p class="field"><small>${f.videos.length - 40} فایل دیگر در صفحه‌ی آرشیو است.</small></p>`;
    h += `</div>`;
    if (vid.alts && vid.alts.length) {
      h += `<details class="alts"><summary>نسخه‌های کم‌حجم‌تر همین فایل (${vid.alts.length})</summary><div class="files">${vid.alts.map((x) => fileRow(x, 0, { alt: true })).join("")}</div></details>`;
    }
    return h;
  }
  function imageFiles(f) {
    const D = S.detail;
    // The picture on screen first, with each of its versions (JPEG and the original TIFF/PNG).
    const order = [D.img, ...f.images.map((_, i) => i).filter((i) => i !== D.img)].slice(0, 40);
    const rows = order.map((i) => f.images[i].variants.map((x) => fileRow(x, 0, { note: x.original ? "فایل اصلی" : "نسخه‌ی JPEG آرشیو", alt: i !== D.img })).join("")).join("");
    return `<h3 class="sec-t">${ic("images")}${f.images.length > 1 ? `عکس‌ها (${f.images.length})` : "فایل عکس"}</h3>
      <div class="files">${rows}</div>`;
  }
  // The version to save when no particular file was chosen: a JPEG/PNG if the picture has one.
  const imgPick = (im) => im.variants.find((v) => /\.(jpe?g|png)$/i.test(v.name)) || im.variants[0];

  // clip times: "m:ss", "h:mm:ss" or seconds
  const parseT = (s) => { s = String(s).trim().replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)); return s.includes(":") ? s.split(":").reduce((a, p) => a * 60 + Number(p || 0), 0) : Number(s) || 0; };
  function bindClip() {
    const upd = () => {
      const a = parseT($("#clipA").value), b = parseT($("#clipB").value);
      $("#clipLen").innerHTML = b > a ? `طول تکه: <b class="num">${NA.fmtTime(b - a) || "0:0" + Math.round(b - a)}</b>` : `<span style="color:var(--restricted)">پایان باید بعد از شروع باشد</span>`;
    };
    $("#clipA").addEventListener("input", upd);
    $("#clipB").addEventListener("input", upd);
    upd();
  }

  // ------------------------------------------------------------------ results from the other sources
  function nfCardHtml(it, k) {
    const lv = NF_LV[it.licence.verdict] || "unknown";
    const inB = S.basket.some((b) => b.id === "nf:" + it._k);
    const short = it.w && it.h ? Math.min(it.w, it.h) : 0;
    const tag = [it.dur ? NA.fmtTime(it.dur) : "", short ? NA.quality(short) : ""].filter(Boolean).join(" ");
    return `<article class="card" tabindex="0" role="button" data-act="nfitem" data-k="${esc(it._k)}" style="--k:${k % 18}">
      <div class="thumb">
        ${safeUrl(it.thumb) ? `<img src="${esc(safeUrl(it.thumb))}" alt="" loading="lazy" referrerpolicy="no-referrer" onload="this.classList.add('ok')" onerror="this.remove()">` : ""}
        <span class="kind">${ic(it.kind === "image" ? "image" : "film-strip")}</span>
        ${inB ? `<span class="in-basket" title="در سبد">${ic("check")}</span>` : ""}
        <span class="tag" ${tag ? "" : "hidden"}>${esc(tag)}</span>
      </div>
      <h3 dir="ltr">${esc(it.title || it.id)}</h3>
      <div class="meta"><span class="lic lic-${lv}">${esc(NF_FA[it.licence.verdict] || "")}</span><span class="en">${esc(srcName(it.source))}</span>${it.year ? `<span class="num">${it.year}</span>` : ""}</div>
    </article>`;
  }
  // a file's name on disk: source-id-label.ext
  function nfName(it, x) {
    const ext = ((/\.(mp4|mov|webm|ogv|mpe?g|jpe?g|png|tiff?|webp|gif)(?=$|[?#])/i.exec(x.url) || [])[0] || (it.kind === "image" ? ".jpg" : ".mp4")).toLowerCase();
    const lab = x.label ? "-" + String(x.label).replace(/[^\w.-]+/g, "") : "";
    return `${it.source}-${String(it.id).replace(/[^\w.-]+/g, "_").slice(0, 60)}${lab}${ext}`;
  }
  function nfCredit(it) {
    const src = NF.SOURCES[it.source] || {};
    return `${it.title}${it.year ? ` (${it.year})` : ""}\n${it.author ? `By: ${it.author}\n` : ""}Source: ${src.name || it.source}, ${it.page || ""}\nLicence: ${it.licence.name}${it.licence.url ? ` (${it.licence.url})` : ""}`;
  }
  // only what is needed to show it again (basket, reload)
  function slim(it) {
    const o = {};
    for (const k of ["source", "id", "kind", "title", "page", "thumb", "preview", "w", "h", "dur", "year", "author", "licence", "collection", "_k"]) o[k] = it[k];
    o.files = (it.files || []).slice(0, 6);
    return o;
  }
  async function openNf(key, fromBasket) {
    const it = (fromBasket ? null : S.results.find((x) => x._k === key)) || ((S.basket.find((b) => b.id === "nf:" + key) || {}).it);
    if (!it) return;
    if (it.source === "archive") { S.cameFromGrid = true; openItem(it.id); return; }
    S.detail = { nf: it };
    renderNfDetail();
    showLayer("drawer");
    // NASA lists an asset's files (and its real size and length) only on request
    if (it.source === "nasa" && !(it.files && it.files.length)) {
      try {
        const full = S.helper.on ? (await api("/api/nf/details", { it })).it : await NF.details(it);
        if (!S.detail || S.detail.nf !== it) return;
        Object.assign(it, full);
        renderNfDetail();
      } catch (e) { toast("فهرست فایل‌ها نیامد: " + e.message, "warning"); }
    }
  }
  function renderNfDetail() {
    const it = S.detail.nf;
    const lv = NF_LV[it.licence.verdict] || "unknown";
    const inB = S.basket.some((b) => b.id === "nf:" + it._k);
    const files = (it.files || []).filter((x) => x && safeUrl(x.url));
    const isImg = it.kind === "image";
    const src = NF.SOURCES[it.source] || {};
    const prev = safeUrl(it.preview) || (!isImg && files.length ? safeUrl(files[files.length - 1].url) : "");
    const media = isImg
      ? `<div class="media"><img src="${esc(safeUrl(it.preview) || safeUrl(it.thumb))}" alt="${esc(it.title)}" referrerpolicy="no-referrer"></div>`
      : prev
        ? `<div class="media"><video id="player" controls preload="metadata" playsinline ${safeUrl(it.thumb) ? `poster="${esc(safeUrl(it.thumb))}"` : ""} src="${esc(prev)}"></video></div>`
        : `<div class="media">${safeUrl(it.thumb) ? `<img src="${esc(safeUrl(it.thumb))}" alt="" referrerpolicy="no-referrer">` : `<div class="noprev">${ic("monitor-play", "big")}پیش‌نمایش ندارد</div>`}</div>`;
    const page = safeUrl(it.page);
    $("#drawer").innerHTML = `
      <div class="d-head">
        <h2>${isImg ? "عکس" : "ویدیو"}</h2>
        ${page ? `<a class="btn sm ghost" href="${esc(page)}" target="_blank" rel="noopener noreferrer">${ic("arrow-square-out")}<span class="en">${esc(src.name || it.source)}</span></a>` : ""}
        <button class="btn icon ghost" data-act="close-item" aria-label="بستن">${ic("x")}</button>
      </div>
      <div class="d-body">
        ${media}
        <h1 class="d-title" dir="ltr">${esc(it.title || it.id)}</h1>
        <div class="d-meta">
          ${it.year ? `<span>سال <b class="num">${it.year}</b></span>` : ""}
          ${it.author ? `<span class="en">${esc(it.author)}</span>` : ""}
          <span>${esc(src.fa || src.name || it.source)}</span>
          ${it.w ? `<span class="num">${it.w}×${it.h}</span>` : ""}
          ${it.dur ? `<span class="num">${NA.fmtTime(it.dur)}</span>` : ""}
        </div>
        <div class="licbox" style="--c:var(--${lv})">
          <span class="lic lic-${lv}">${esc(NF_FA[it.licence.verdict] || "")}</span>
          ${(it.flags || []).map((f) => (NF.FLAGS && NF.FLAGS[f] ? `<p class="warn">${esc(NF.FLAGS[f].fa)}</p>` : "")).join("")}
          <p>${esc(NF_WHY[it.licence.verdict] || "")}</p>
          ${safeUrl(it.licence.url) ? `<a class="en" href="${esc(safeUrl(it.licence.url))}" target="_blank" rel="noopener noreferrer">${esc(it.licence.name || it.licence.url)}</a>` : it.licence.name ? `<span class="en">${esc(it.licence.name)}</span>` : ""}
          ${src.lic ? `<p>${esc(src.lic)}</p>` : ""}
        </div>
        <div class="acts">
          <button class="btn ${inB ? "ghost" : "primary"}" data-act="nf-basket">${ic(inB ? "check" : "basket")}${inB ? "در سبد است" : "افزودن به سبد"}</button>
          <button class="btn ghost" data-act="nf-credit">${ic("copy")}کپی منبع برای توضیحات</button>
        </div>
        <h3 class="sec-t">${ic(isImg ? "images" : "film-strip")}${files.length > 1 ? `فایل‌ها (${files.length})` : "فایل"}</h3>
        <div class="files">${files.length ? files.slice(0, 12).map((x) => nfFileRow(it, x)).join("") : `<p class="field"><small>${it.source === "nasa" ? "در حال گرفتن فهرست فایل‌ها…" : "فایلش را از صفحه‌ی منبع بگیر."}</small></p>`}</div>
        ${S.helper.on && S.helper.ffmpeg && !isImg ? `<p class="field"><small>${ic("info")} برای بریدن فقط یک تکه، فایل را دانلود کن؛ یا در کیت NFP به Claude بگو همین را با <span class="lat">footage.mjs</span> ببُرد.</small></p>` : ""}
        <div class="credit"><h3 class="sec-t">${ic("file-text")}منبع (برای توضیحات ویدیو)</h3><pre>${esc(nfCredit(it))}</pre></div>
        ${it.desc ? `<h3 class="sec-t">${ic("info")}توضیحات</h3><div class="desc" dir="ltr">${esc(String(it.desc).slice(0, 3000))}</div>` : ""}
      </div>`;
  }
  function nfFileRow(it, x) {
    const name = nfName(it, x);
    const short = x.w && x.h ? Math.min(x.w, x.h) : 0;
    const meta = [x.w ? `<span class="num">${x.w}×${x.h}</span>` : "", short ? `<span>${NA.quality(short)}</span>` : "", x.label ? `<span class="en">${esc(x.label)}</span>` : "", x.size ? `<span class="num">${NA.fmtSize(x.size)}</span>` : ""].filter(Boolean).join("");
    const dl = S.helper.on
      ? `<button class="btn sm primary" data-act="nf-dl" data-url="${esc(x.url)}" data-name="${esc(name)}" data-size="${x.size || 0}">${ic("download-simple")}دانلود</button>`
      : `<a class="btn sm primary" href="${esc(x.url)}" download target="_blank" rel="noopener noreferrer">${ic("download-simple")}دانلود</a>`;
    return `<div class="file">
      <div class="fn" title="${esc(name)}">${esc(name)}</div>
      <div class="fa"><button class="btn icon sm ghost" data-act="copy-link" data-url="${esc(x.url)}" aria-label="کپی لینک">${ic("link")}</button>${dl}</div>
      <div class="fm">${meta}</div>
    </div>`;
  }
  function nfToggleBasket() {
    const it = S.detail.nf, id = "nf:" + it._k;
    const i = S.basket.findIndex((b) => b.id === id);
    if (i >= 0) { S.basket.splice(i, 1); toast("از سبد برداشته شد", "trash"); }
    else {
      const best = (it.files || []).find((x) => x && safeUrl(x.url));
      S.basket.push({
        id, nf: true, title: it.title || it.id, year: it.year || "", mediatype: it.kind === "image" ? "image" : "movies", level: NF_LV[it.licence.verdict] || "unknown",
        why: "", lic: it.licence.url || "", thumb: it.thumb || "", page: it.page || "", credit: nfCredit(it).replace(/\n/g, " · "),
        files: best ? [{ url: best.url, name: nfName(it, best), size: best.size || 0 }] : [], it: slim(it), added: Date.now(),
      });
      toast("به سبد اضافه شد", "basket");
    }
    saveBasket();
    renderNfDetail();
    const card = document.querySelector(`.card[data-k="${CSS.escape(it._k)}"] .thumb`);
    if (card) {
      const mark = card.querySelector(".in-basket");
      if (i >= 0 && mark) mark.remove();
      if (i < 0 && !mark) card.insertAdjacentHTML("beforeend", `<span class="in-basket" title="در سبد">${ic("check")}</span>`);
    }
  }
  async function nfDownload(x) {
    const it = S.detail && S.detail.nf;
    try {
      await api("/api/download", { url: x.url, name: x.name, size: x.size || 0, id: it ? `${it.source}-${it.id}` : "misc", title: it ? it.title : "", licence: it ? nfCredit(it).replace(/\n/g, " · ") : "", page: it ? it.page : "", track: it && it.files && it.files[0] && it.files[0].track });
      toast("به صف دانلود اضافه شد", "download-simple");
      pollJobs();
    } catch (e) { toast("دانلود شروع نشد: " + e.message, "warning"); }
  }

  // ------------------------------------------------------------------ basket
  function saveBasket() { store.set("basket", S.basket); updateCounts(); }
  function basketEntry(m) {
    const v = NA.verdict(Object.assign({}, m, { identifier: m.identifier }));
    return { id: m.identifier, title: m.title || m.identifier, year: NA.yearOf(m) || "", mediatype: m.mediatype, level: v.level, why: v.why, lic: v.lic || "", added: Date.now() };
  }
  function toggleBasket() {
    const m = S.detail.meta.metadata;
    const i = S.basket.findIndex((b) => b.id === m.identifier);
    if (i >= 0) { S.basket.splice(i, 1); toast("از سبد برداشته شد", "trash"); }
    else { S.basket.push(basketEntry(m)); toast("به سبد اضافه شد", "basket"); }
    saveBasket();
    renderDetail();
    const card = document.querySelector(`.card[data-id="${CSS.escape(m.identifier)}"] .thumb`);
    if (card) {
      const mark = card.querySelector(".in-basket");
      if (i >= 0 && mark) mark.remove();
      if (i < 0 && !mark) card.insertAdjacentHTML("beforeend", `<span class="in-basket" title="در سبد">${ic("check")}</span>`);
    }
  }
  function renderBasket() {
    const items = S.basket;
    const helperBtn = S.helper.on ? `<button class="btn primary" data-act="basket-dl" ${items.length ? "" : "disabled"}>${ic("download-simple")}دانلود همه</button>` : "";
    $("#panel").innerHTML = `
      <div class="d-head"><h2>سبد <span class="num">(${items.length})</span></h2><button class="btn icon ghost" data-act="close-panel" aria-label="بستن">${ic("x")}</button></div>
      <div class="d-body">
        ${items.length ? items.map((b) => `
          <div class="b-item">
            <img src="${b.nf ? esc(safeUrl(b.thumb)) : NA.thumb(b.id)}" alt="" loading="lazy" referrerpolicy="no-referrer">
            <div style="min-width:0"><div class="t" dir="ltr">${esc(b.title)}</div><div class="s"><span class="lic lic-${b.level}">${esc(b.nf && b.it ? NF_FA[b.it.licence.verdict] || "" : NA.LEVELS[b.level].short)}</span>${b.nf && b.it ? `<span class="en">${esc(srcName(b.it.source))}</span>` : ""}${b.year ? `<span class="num">${b.year}</span>` : ""}</div></div>
            <div style="display:flex;gap:4px"><button class="btn icon sm ghost" data-act="${b.nf ? "nf-open" : "item"}" data-id="${esc(b.id)}" aria-label="باز کردن">${ic("arrow-square-out")}</button><button class="btn icon sm ghost" data-act="basket-rm" data-id="${esc(b.id)}" aria-label="حذف">${ic("trash")}</button></div>
          </div>`).join("")
        : `<div class="empty-s">${ic("basket")}سبد خالی است. از صفحه‌ی هر فیلم یا عکس «افزودن به سبد» را بزن تا برای یک ویدیو جمعشان کنی.</div>`}
      </div>
      <div class="d-foot">
        ${helperBtn}
        <button class="btn ghost" data-act="basket-links" ${items.length ? "" : "disabled"}>${ic("link")}کپی همه‌ی لینک‌ها</button>
        <button class="btn ghost" data-act="basket-md" ${items.length ? "" : "disabled"}>${ic("file-text")}فهرست Markdown</button>
        <button class="btn ghost" data-act="basket-clear" ${items.length ? "" : "disabled"}>${ic("trash")}خالی کردن</button>
      </div>`;
  }
  // The best file of an item: the largest original video, or every image.
  async function bestFiles(id) {
    const nb = S.basket.find((b) => b.id === id && b.nf);
    if (nb) return nb.files || [];
    const f = NA.pickFiles(await NA.metadata(id));
    if (f.videos.length) return [f.videos[0]];
    if (f.images.length) return f.images.slice(0, 30).map(imgPick);
    return [];
  }
  async function basketLinks() {
    toast("در حال جمع کردن لینک‌ها…", "link");
    const out = [];
    for (const b of S.basket) { try { for (const x of await bestFiles(b.id)) out.push(x.url); } catch {} }
    copy(out.join("\n"), `${out.length} لینک کپی شد (برای IDM: Add batch download from clipboard)`);
  }
  async function basketMarkdown() {
    const lines = ["# NFP Archive: فهرست منابع", ""];
    const groups = ["free", "claimed", "restricted", "unknown"];
    for (const lv of groups) {
      const items = S.basket.filter((b) => b.level === lv);
      if (!items.length) continue;
      lines.push(`## ${NA.LEVELS[lv].fa}`, "");
      for (const b of items) {
        let files = [];
        try { files = await bestFiles(b.id); } catch {}
        lines.push(`- **${b.title}**${b.year ? ` (${b.year})` : ""}: ${b.nf ? b.page : NA.itemUrl(b.id)}`);
        lines.push(`  - ${b.nf ? b.credit : NA.CREDIT_EN[b.why] || ""}`);
        for (const x of files.slice(0, 5)) lines.push(`  - ${x.url}${x.size ? ` (${NA.fmtSize(x.size)})` : ""}`);
      }
      lines.push("");
    }
    lines.push("Each item's source and licence are on its line above.");
    const blob = new Blob([lines.join("\n")], { type: "text/markdown;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `nfp-archive-${new Date().toISOString().slice(0, 10)}.md`;
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    toast("فهرست ذخیره شد", "file-text");
  }

  // ------------------------------------------------------------------ helper (start.bat)
  async function api(path, body) {
    const r = await fetch(path, { method: body ? "POST" : "GET", headers: Object.assign({ "X-NFP-Token": TOKEN }, body ? { "Content-Type": "application/json" } : {}), body: body ? JSON.stringify(body) : undefined });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "HTTP " + r.status);
    return j;
  }
  async function detectHelper() {
    if (!TOKEN || !/^https?:$/.test(location.protocol)) return;
    try {
      const j = await api("/api/ping");
      S.helper.on = true;
      S.helper.ffmpeg = !!j.ffmpeg;
      S.helper.settings = j.settings;
      S.helper.sources = j.sources || [];
      $("#dlbtn").hidden = false;
      pollJobs();
      if (!$("#main").dataset.ready) return;
      if (S.route.view === "home") renderHome();
      else { document.querySelectorAll(".lite-note").forEach((n) => n.remove()); renderFilters(); }
      if (S.detail && S.detail.meta) renderDetail();
      if (S.detail && S.detail.nf) renderNfDetail();
    } catch {}
  }
  let pollT = 0;
  async function pollJobs() {
    clearTimeout(pollT);
    try {
      const j = await api("/api/jobs");
      S.helper.jobs = j.jobs;
      updateCounts();
      if (S.panel === "downloads") renderDownloads();
    } catch {}
    const active = S.helper.jobs.some((x) => /queued|running|probing/.test(x.status));
    pollT = setTimeout(pollJobs, active || S.panel === "downloads" ? 1000 : 4000);
  }
  async function helperDownload(x, extra = {}) {
    const m = S.detail ? S.detail.meta.metadata : null;
    const v = m ? NA.verdict(Object.assign({}, m)) : null;
    try {
      await api("/api/download", Object.assign({ url: x.url, name: x.name, size: x.size || 0, id: m && m.identifier, title: m && m.title, licence: v ? NA.CREDIT_EN[v.why] : "" }, extra));
      toast("به صف دانلود اضافه شد", "download-simple");
      pollJobs();
    } catch (e) { toast("دانلود شروع نشد: " + e.message, "warning"); }
  }
  async function helperClip() {
    const D = S.detail, vid = D.files.videos[D.cur], m = D.meta.metadata;
    const a = parseT($("#clipA").value), b = parseT($("#clipB").value);
    if (!(b > a)) return toast("پایان باید بعد از شروع باشد", "warning");
    if (b - a > 1800) return toast("هر تکه حداکثر ۳۰ دقیقه", "warning");
    const v = NA.verdict(Object.assign({}, m));
    try {
      await api("/api/clip", { url: vid.url, name: vid.name, start: a, end: b, size: vid.size, len: vid.len, id: m.identifier, title: m.title, licence: NA.CREDIT_EN[v.why] });
      toast("بریدن شروع شد؛ وضعیتش در «دانلودها» است", "scissors");
      pollJobs();
    } catch (e) { toast("بریدن شروع نشد: " + e.message, "warning"); }
  }
  async function basketDownloadAll() {
    let n = 0;
    for (const b of S.basket) {
      try {
        for (const x of await bestFiles(b.id)) { await api("/api/download", { url: x.url, name: x.name, size: x.size || 0, id: b.nf ? b.id.replace(/^nf:/, "").replace(/:/, "-") : b.id, title: b.title, licence: b.nf ? b.credit : NA.CREDIT_EN[b.why], page: b.nf ? b.page : "" }); n++; }
      } catch {}
    }
    toast(`${n} فایل به صف دانلود رفت`, "download-simple");
    pollJobs();
  }
  const STATUS_FA = { queued: "در صف", probing: "آماده‌سازی", running: "در حال دانلود", paused: "متوقف", done: "تمام شد", error: "خطا", canceled: "لغو شد" };
  function renderDownloads() {
    const jobs = S.helper.jobs;
    const set = S.helper.settings || {};
    $("#panel").innerHTML = `
      <div class="d-head"><h2>دانلودها</h2><button class="btn icon sm ghost" data-act="settings" aria-label="تنظیمات">${ic("sliders-horizontal")}</button><button class="btn icon ghost" data-act="close-panel" aria-label="بستن">${ic("x")}</button></div>
      <div class="d-body">
        ${jobs.length ? jobs.map((j) => {
          const p = j.status === "done" ? 100 : j.total ? Math.min(100, (j.done / j.total) * 100) : 0;
          const bytes = j.unit !== "s";
          const speed = j.status === "running" && bytes && j.speed ? `${NA.fmtSize(j.speed)}/s` : "";
          const eta = j.status === "running" && bytes && j.speed && j.total ? NA.fmtTime((j.total - j.done) / j.speed) : "";
          const amount = !j.total ? "" : bytes ? `${NA.fmtSize(j.done)} / ${NA.fmtSize(j.total)}` : `${NA.fmtTime(j.done) || "0:00"} / ${NA.fmtTime(j.total)}`;
          const phase = j.kind === "clip" && j.status === "running" ? (j.phase === "encode" ? "ساخت MP4" : "دریافت تکه") : STATUS_FA[j.status] || j.status;
          return `<div class="job ${esc(j.status)}">
            <div class="t" dir="ltr" title="${esc(j.file || j.name)}">${esc(j.file || j.name)}</div>
            <div class="bar"><i style="--p:${p.toFixed(1)}%"></i></div>
            <div class="s"><span>${j.kind === "clip" ? ic("scissors") + " " : ""}${esc(phase)}${j.error ? `: <span class="en">${esc(j.error)}</span>` : ""}</span><span class="num">${amount} ${speed} ${eta ? "| " + eta : ""}</span></div>
            <div class="acts">
              ${j.status === "running" || j.status === "queued" ? `<button class="btn sm ghost" data-act="job" data-op="pause" data-id="${esc(j.id)}">${ic("pause")}توقف</button>` : ""}
              ${j.status === "paused" || j.status === "error" ? `<button class="btn sm ghost" data-act="job" data-op="resume" data-id="${esc(j.id)}">${ic("play")}ادامه</button>` : ""}
              ${j.status === "done" ? `<button class="btn sm ghost" data-act="job" data-op="reveal" data-id="${esc(j.id)}">${ic("folder-open")}نمایش فایل</button>` : ""}
              ${/running|queued|paused|probing/.test(j.status) ? `<button class="btn sm ghost" data-act="job" data-op="cancel" data-id="${esc(j.id)}">${ic("x")}لغو</button>` : `<button class="btn sm ghost" data-act="job" data-op="remove" data-id="${esc(j.id)}">${ic("trash")}حذف از فهرست</button>`}
            </div>
          </div>`;
        }).join("") : `<div class="empty-s">${ic("cloud-arrow-down")}هنوز دانلودی نیست.</div>`}
      </div>
      <div class="d-foot"><button class="btn ghost" data-act="open-dir">${ic("folder-open")}باز کردن پوشه‌ی دانلود</button><span class="en" style="font-size:12px;color:var(--muted);align-self:center;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%">${esc(set.dir || "")}</span></div>`;
  }
  function renderSettings() {
    const s = S.helper.settings || {};
    $("#panel").innerHTML = `
      <div class="d-head"><button class="btn icon sm ghost" data-act="downloads" aria-label="برگشت">${ic("arrow-right")}</button><h2>تنظیمات دانلود</h2><button class="btn icon ghost" data-act="close-panel" aria-label="بستن">${ic("x")}</button></div>
      <div class="d-body stack">
        <div class="field"><label for="setDir">پوشه‌ی دانلود</label><input id="setDir" class="en" dir="ltr" value="${esc(s.dir || "")}"><small>اگر درایو C پر است، یک پوشه روی درایو دیگر بده.</small></div>
        <div class="field"><label for="setConn">تعداد اتصال هم‌زمان برای هر فایل</label><input id="setConn" class="num" inputmode="numeric" value="${esc(s.connections || 8)}"><small>از ایران معمولاً ۸ اتصال چند برابر سریع‌تر از یکی است. بین ۱ تا ۱۶.</small></div>
        <div class="field"><label for="setProxy">پراکسی (اختیاری)</label><input id="setProxy" class="en" dir="ltr" placeholder="http://127.0.0.1:8080" value="${esc(s.proxy || "")}"><small>اگر خالی باشد مستقیم وصل می‌شود.</small></div>
        <div class="field"><label>ffmpeg (برای بریدن تکه)</label><small>${S.helper.ffmpeg ? "پیدا شد؛ بریدن فعال است." : "پیدا نشد؛ برای بریدن تکه ffmpeg را نصب کن یا مسیرش را در settings.json بنویس."}</small></div>
        <div class="field"><label>کلیدهای رایگان برای منبع‌های بیشتر (اختیاری)</label>
          ${KEY_UI.map(([k, label]) => `<input id="key-${k}" class="en" dir="ltr" type="password" autocomplete="off" aria-label="${label}" placeholder="${label}: ${(s.keys || {})[k] ? "ذخیره شده (برای پاک کردن - بنویس)" : "کلید را اینجا بگذار"}">`).join("")}
          <small>کلید فقط روی همین کامپیوتر در settings.json می‌ماند و جز برای خود آن سایت فرستاده نمی‌شود. ساخت کلید رایگان: pexels.com/api · pixabay.com/api/docs · unsplash.com/developers · pro.europeana.eu/page/get-api</small></div>
      </div>
      <div class="d-foot"><button class="btn primary" data-act="save-settings">${ic("check")}ذخیره</button></div>`;
  }
  async function saveSettings() {
    try {
      const keys = {};
      for (const [k] of KEY_UI) {
        const v = ($("#key-" + k) || {}).value || "";
        if (v.trim() === "-") keys[k] = "";
        else if (v.trim()) keys[k] = v.trim();
      }
      const j = await api("/api/settings", { dir: $("#setDir").value.trim(), connections: Number($("#setConn").value) || 8, proxy: $("#setProxy").value.trim(), keys });
      S.helper.settings = j.settings;
      if (j.sources) { S.helper.sources = j.sources; renderFilters(); }
      toast("ذخیره شد");
      openPanel("downloads");
    } catch (e) { toast("ذخیره نشد: " + e.message, "warning"); }
  }

  const KEY_UI = [["PEXELS_API_KEY", "Pexels"], ["PIXABAY_API_KEY", "Pixabay"], ["UNSPLASH_ACCESS_KEY", "Unsplash"], ["EUROPEANA_API_KEY", "Europeana"]];

  // ------------------------------------------------------------------ layers
  function showLayer(which) {
    $("#" + which).classList.add("on");
    $("#" + which).setAttribute("aria-hidden", "false");
    $("#scrim").classList.add("on");
    document.body.style.overflow = "hidden";
  }
  function hideLayer(which) {
    $("#" + which).classList.remove("on");
    $("#" + which).setAttribute("aria-hidden", "true");
    if (!$("#drawer").classList.contains("on") && !$("#panel").classList.contains("on")) {
      $("#scrim").classList.remove("on");
      document.body.style.overflow = "";
    }
  }
  function openPanel(name) {
    S.panel = name;
    if (name === "basket") renderBasket();
    if (name === "downloads") renderDownloads();
    if (name === "settings") renderSettings();
    showLayer("panel");
  }
  function closePanel() { S.panel = null; hideLayer("panel"); }
  function updateCounts() {
    const bc = $("[data-act=basket] .count");
    bc.textContent = S.basket.length;
    bc.hidden = !S.basket.length;
    const active = S.helper.jobs.filter((x) => /queued|running|probing/.test(x.status)).length;
    const dc = $("#dlbtn .count");
    dc.textContent = active;
    dc.hidden = !active;
  }

  // ------------------------------------------------------------------ events
  document.addEventListener("click", (e) => {
    const t = e.target.closest("[data-act]");
    if (!t) return;
    const act = t.dataset.act;
    switch (act) {
      case "cat": location.hash = `#/c/${t.dataset.cat}/`; break;
      case "go": location.hash = t.dataset.href; break;
      case "suggest": location.hash = `#/s/${encodeURIComponent(t.dataset.q)}`; break;
      case "filter": setFilter(t.dataset.k, t.dataset.v); break;
      case "reset-filters": S.filters.type = "all"; S.filters.licence = "all"; S.filters.decade = ""; setFilter("sort", S.filters.sort); break;
      case "retry": runSearch(false); break;
      case "more": S.page++; runSearch(true); break;
      case "item": S.cameFromGrid = true; closePanel(); openItem(t.dataset.id); break;
      case "nfitem": closePanel(); openNf(t.dataset.k); break;
      case "nf-open": closePanel(); openNf(t.dataset.id.replace(/^nf:/, ""), true); break;
      case "nf-dl": nfDownload({ url: t.dataset.url, name: t.dataset.name, size: Number(t.dataset.size) }); break;
      case "nf-basket": nfToggleBasket(); break;
      case "nf-credit": copy(nfCredit(S.detail.nf), "منبع کپی شد"); break;
      case "close-item": closeItem(); break;
      case "close": if (S.panel) closePanel(); else if (S.detail) closeItem(); break;
      case "pick-img": S.detail.img = Number(t.dataset.i); renderDetail(); break;
      case "play": S.detail.cur = Number(t.dataset.i); renderDetail(); { const p = $("#player"); if (p) p.play().catch(() => {}); } break;
      case "copy-link": copy(t.dataset.url, "لینک کپی شد"); break;
      case "copy-credit": { const m = S.detail.meta.metadata; copy(creditText(m, NA.verdict(Object.assign({}, m))), "منبع کپی شد"); } break;
      case "basket-toggle": toggleBasket(); break;
      case "basket": openPanel("basket"); break;
      case "basket-rm": S.basket = S.basket.filter((b) => b.id !== t.dataset.id); saveBasket(); renderBasket(); break;
      case "basket-clear": if (confirm("سبد خالی شود؟")) { S.basket = []; saveBasket(); renderBasket(); } break;
      case "basket-links": basketLinks(); break;
      case "basket-md": basketMarkdown(); break;
      case "basket-dl": basketDownloadAll(); break;
      case "close-panel": closePanel(); break;
      case "downloads": openPanel("downloads"); break;
      case "settings": openPanel("settings"); break;
      case "save-settings": saveSettings(); break;
      case "open-dir": api("/api/open-dir", {}).catch((er) => toast(er.message, "warning")); break;
      case "dl": helperDownload({ url: t.dataset.url, name: t.dataset.name, size: Number(t.dataset.size) }); break;
      case "clip": helperClip(); break;
      case "clip-a": case "clip-b": {
        const p = $("#player");
        if (!p) break;
        $(act === "clip-a" ? "#clipA" : "#clipB").value = NA.fmtTime(p.currentTime) || "0:00";
        $("#clipA").dispatchEvent(new Event("input"));
        break;
      }
      case "job": api(`/api/jobs/${t.dataset.id}/${t.dataset.op}`, {}).then(pollJobs).catch((er) => toast(er.message, "warning")); break;
      case "theme": {
        const next = root.dataset.theme === "dark" ? "light" : "dark";
        root.dataset.theme = next;
        store.set("theme", next);
        $("[data-act=theme]").innerHTML = ic(next === "dark" ? "sun" : "moon");
        break;
      }
      case "clear": $("#q").value = ""; $("#q").focus(); updateHint(); break;
    }
  });
  document.addEventListener("change", (e) => {
    const t = e.target.closest("[data-act=filter-sel]");
    if (t) setFilter(t.dataset.k, t.value);
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") { if (S.panel) closePanel(); else if (S.detail) closeItem(); }
    if (e.key === "/" && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { e.preventDefault(); $("#q").focus(); }
    if (e.key === "Enter" && document.activeElement.classList.contains("card")) document.activeElement.click();
  });
  $("#sform").addEventListener("submit", (e) => {
    e.preventDefault();
    const v = $("#q").value.trim();
    $("#shint").hidden = true;
    if (v) location.hash = `#/s/${encodeURIComponent(v)}`;
  });
  function updateHint() {
    const v = $("#q").value.trim();
    $("[data-act=clear]").hidden = !v;
    const h = $("#shint");
    if (!v || !NA.hasPersian(v)) { h.hidden = true; return; }
    const q = prepQuery(v);
    h.innerHTML = q.en ? `${ic("translate")}<span>به انگلیسی:</span> <code>${esc(q.en)}</code>${q.decade ? ` <span>+ ${esc((NA.DECADES.find((d) => d.id === q.decade) || {}).fa || "")}</span>` : ""}${q.unknown.length ? ` <span class="warn">ناشناخته: ${esc(q.unknown.join("، "))}</span>` : ""}` : `${ic("warning")}<span>این کلمه‌ها را نمی‌شناسم؛ انگلیسی بنویس.</span>`;
    h.hidden = false;
  }
  $("#q").addEventListener("input", updateHint);
  $("#q").addEventListener("blur", () => setTimeout(() => ($("#shint").hidden = true), 150));
  $("#q").addEventListener("focus", updateHint);
  window.addEventListener("hashchange", onRoute);

  // ------------------------------------------------------------------ start
  $("[data-act=theme]").innerHTML = ic(root.dataset.theme === "dark" ? "sun" : "moon");
  $(".s-icon").innerHTML = ic("magnifying-glass");
  $("[data-act=clear]").innerHTML = ic("x");
  $("[data-act=basket]").insertAdjacentHTML("afterbegin", ic("basket"));
  $("#dlbtn").insertAdjacentHTML("afterbegin", ic("cloud-arrow-down"));
  updateCounts();
  // the helper first (it decides which sources can be searched), then the page
  detectHelper().finally(onRoute);
})();
