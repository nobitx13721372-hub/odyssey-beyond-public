// NFP Archive — topic categories. Each topic is a search clause (see NA.topicClause in core.js):
//   t   words matched in the title and subject tags ("a OR b", "\"exact phrase\"")
//   c   collections, OR-ed with t        q   a raw archive.org clause, OR-ed        and   a raw clause added with AND
//   type   the media the topic is best for (movies | image); the person can still switch it
// A category with fiction: true keeps feature films, TV series and cartoons; the others leave them out.
// Every query was run against archive.org and its top results checked (tools/test-queries.mjs).
(function (G) {
  const NA = (G.NA = G.NA || {});
  NA.CATEGORIES = [
    {
      id: "space", fa: "فضا و نجوم", en: "Space", icon: "rocket",
      topics: [
        { id: "apollo", fa: "آپولو و فرود روی ماه", t: 'apollo OR "moon landing" OR lunar' },
        { id: "launch", fa: "پرتاب موشک", t: '"saturn v" OR rocket OR rockets OR "rocket launch"' },
        { id: "shuttle", fa: "شاتل فضایی", t: '"space shuttle" OR "shuttle launch"' },
        { id: "station", fa: "ایستگاه فضایی", t: '"space station" OR "international space station" OR skylab' },
        { id: "planets", fa: "سیاره‌ها و منظومه‌ی شمسی", t: 'mars OR jupiter OR planet OR planets OR "solar system"' },
        { id: "galaxies", fa: "کهکشان و تلسکوپ", t: "hubble OR galaxy OR galaxies OR nebula OR telescope" },
        { id: "astronauts", fa: "فضانوردها", t: "astronaut OR astronauts OR cosmonaut OR spacewalk" },
        { id: "race", fa: "مسابقه‌ی فضایی و شوروی", t: 'sputnik OR gagarin OR "space race" OR "vostok"' },
      ],
    },
    {
      id: "war", fa: "تاریخ و جنگ‌ها", en: "History & war", icon: "helmet",
      topics: [
        { id: "ww1", fa: "جنگ جهانی اول", t: '"world war i" OR "world war 1" OR "first world war" OR "great war" OR wwi' },
        { id: "ww2", fa: "جنگ جهانی دوم", t: '"world war ii" OR "world war 2" OR "second world war" OR wwii' },
        { id: "cold", fa: "جنگ سرد و بمب اتم", t: '"cold war" OR "atomic bomb" OR "nuclear test" OR "civil defense" OR "atomic attack"' },
        { id: "korea", fa: "جنگ کره و ویتنام", t: 'vietnam OR "korean war"' },
        { id: "newsreels", fa: "نیوزریل‌ها (اخبار سینمایی)", c: "universal_newsreels", t: "newsreel OR newsreels" },
        { id: "leaders", fa: "رهبران و سخنرانی‌ها", t: 'kennedy OR roosevelt OR churchill OR eisenhower OR truman OR "martin luther king"' },
        { id: "depression", fa: "رکود بزرگ", t: '"great depression" OR "dust bowl"' },
      ],
    },
    {
      id: "iran", fa: "ایران و خاورمیانه", en: "Iran & the Middle East", icon: "dome",
      topics: [
        { id: "iran", fa: "ایران تا دهه‌ی ۴۰ میلادی", t: "iran OR persia OR iranian OR tehran OR teheran OR isfahan OR shiraz OR persepolis", and: "year:[1890 TO 1941]" },
        { id: "pahlavi", fa: "ایران دوره‌ی پهلوی تا انقلاب", t: 'iran OR persia OR iranian OR tehran OR teheran OR "shah of iran" OR pahlavi OR khomeini OR "hostage crisis"', and: "year:[1941 TO 1990]" },
        { id: "tehran", fa: "تهران", t: "tehran OR teheran" },
        { id: "shahnameh", fa: "شاهنامه و نگارگری ایرانی", t: 'shahnama OR shahnameh OR "shah-nama" OR "book of kings" OR "persian painting" OR safavid OR qajar OR timurid', type: "image" },
        { id: "oil", fa: "نفت و خلیج فارس", t: '"persian gulf" OR abadan OR "anglo-iranian" OR "oil fields"' },
        { id: "mideast", fa: "خاورمیانه", t: '"middle east" OR egypt OR iraq OR arabia OR afghanistan OR turkey' },
        { id: "desert", fa: "صحرا و تمدن‌های باستان", t: "pyramids OR desert OR mesopotamia OR babylon OR persepolis OR archaeology" },
      ],
    },
    {
      id: "art", fa: "هنر و نقاشی‌های تاریخی", en: "Art & museums", icon: "frame",
      topics: [
        { id: "paintings", fa: "نقاشی‌های کلاسیک", t: 'painting OR "oil on canvas" OR portrait OR landscape', type: "image", and: "collection:(clevelandart OR metropolitanmuseumofart-gallery OR brooklynmuseum OR Fine-Art-History)" },
        { id: "persian", fa: "نگارگری ایرانی", t: 'shahnama OR shahnameh OR "shah-nama" OR "persian painting" OR safavid OR qajar OR timurid OR iran', type: "image", and: "collection:(clevelandart OR metropolitanmuseumofart-gallery OR brooklynmuseum)" },
        { id: "japan", fa: "هنر ژاپن (اوکیوئه)", t: 'ukiyo-e OR woodblock OR hokusai OR hiroshige OR utamaro OR japanese', type: "image", and: "collection:(clevelandart OR metropolitanmuseumofart-gallery OR brooklynmuseum)" },
        { id: "egypt", fa: "مصر باستان", t: "egyptian OR egypt OR pharaoh OR hieroglyph OR mummy", type: "image", and: "collection:(clevelandart OR metropolitanmuseumofart-gallery OR brooklynmuseum)" },
        { id: "greek", fa: "یونان و روم باستان", t: "greek OR roman OR greece OR rome OR hellenistic", type: "image", and: "collection:(clevelandart OR metropolitanmuseumofart-gallery OR brooklynmuseum)" },
        { id: "photos", fa: "عکس‌های قدیمی", c: "picfreededphotos", type: "image" },
        { id: "maps", fa: "نقشه‌های قدیمی", c: "maps_usgs", t: "map OR maps OR atlas", type: "image" },
      ],
    },
    {
      id: "tech", fa: "تکنولوژی و کامپیوتر", en: "Technology", icon: "chip",
      topics: [
        { id: "apple", fa: "تاریخ اپل", c: "applemedia", t: '"apple computer" OR macintosh OR "steve jobs"' },
        { id: "computers", fa: "کامپیوترهای قدیمی", t: 'computer OR computers OR univac OR eniac OR mainframe', c: "computercommercials" },
        { id: "microsoft", fa: "مایکروسافت و ویندوز", t: '"bill gates" OR "windows 95" OR "windows 3.1" OR "ms-dos" OR "microsoft windows"' },
        { id: "games", fa: "بازی‌های ویدیویی قدیمی", t: '"video game" OR "video games" OR atari OR nintendo OR arcade', c: "videogamecommercials" },
        { id: "robots", fa: "ربات و اتوماسیون", t: 'robot OR robots OR automation OR "electronic brain"' },
        { id: "phone", fa: "تلفن و ارتباطات", t: 'telephone OR "bell system" OR telegraph OR switchboard OR "bell telephone"' },
        { id: "internet", fa: "اینترنت و دهه‌ی ۹۰", t: '"world wide web" OR "information superhighway" OR cyberspace OR modem OR "the internet"', and: "-title:(shocker)" },
      ],
    },
    {
      id: "science", fa: "علم و پزشکی", en: "Science & medicine", icon: "atom",
      topics: [
        { id: "atom", fa: "اتم و انرژی هسته‌ای", t: 'atom OR atomic OR nuclear OR radiation OR "atomic energy"' },
        { id: "body", fa: "بدن انسان و پزشکی", t: '"human body" OR medicine OR medical OR surgery OR hospital OR heart' },
        { id: "brain", fa: "مغز و روان", t: "brain OR psychology OR mental OR emotions OR nervous" },
        { id: "lab", fa: "آزمایشگاه و اختراع", t: "laboratory OR experiment OR experiments OR scientist OR invention OR inventor" },
        { id: "electric", fa: "برق و الکتریسیته", t: "electricity OR electric OR electronics OR electron" },
        { id: "germs", fa: "میکروب و بیماری", t: "germs OR bacteria OR disease OR virus OR polio OR vaccine" },
      ],
    },
    {
      id: "nature", fa: "طبیعت و حیوانات", en: "Nature & animals", icon: "leaf",
      topics: [
        { id: "animals", fa: "حیوانات", t: "animals OR wildlife OR zoo OR birds OR insects" },
        { id: "ocean", fa: "اقیانوس و زیر آب", t: "ocean OR underwater OR sea OR whale OR whales OR fish OR coral" },
        { id: "volcano", fa: "آتشفشان و زلزله", t: "volcano OR volcanoes OR earthquake OR eruption OR lava" },
        { id: "weather", fa: "طوفان و آب‌وهوا", t: 'storm OR hurricane OR tornado OR flood OR blizzard OR weather OR meteorology' },
        { id: "landscape", fa: "منظره و کوه", t: 'landscape OR mountains OR "national park" OR scenery OR yellowstone OR "grand canyon"' },
        { id: "plants", fa: "گل و گیاه", t: "flowers OR plants OR garden OR trees OR forest" },
        { id: "earth", fa: "زمین از بالا", t: '"earth from space" OR "earth observation" OR "blue marble" OR "earth views"' },
      ],
    },
    {
      id: "city", fa: "شهرها و زندگی قدیم", en: "Cities & everyday life", icon: "city",
      topics: [
        { id: "newyork", fa: "نیویورک قدیم", t: '"new york" OR manhattan OR "times square" OR brooklyn' },
        { id: "europe", fa: "شهرهای اروپا", t: "paris OR london OR berlin OR rome OR venice OR vienna" },
        { id: "fifties", fa: "زندگی آمریکایی دهه‌ی ۵۰", t: '"social guidance" OR suburbia OR teenagers OR "family life" OR dating', and: "year:[1940 TO 1965]" },
        { id: "home", fa: "خانه و آشپزخانه", t: 'kitchen OR housewife OR "home economics" OR cooking OR housework OR appliances' },
        { id: "school", fa: "مدرسه و آموزش", t: "school OR classroom OR students OR teacher OR education" },
        { id: "fashion", fa: "مد و لباس", t: 'fashion OR clothing OR "fashion show" OR hats OR dresses' },
        { id: "homemovies", fa: "فیلم‌های خانوادگی قدیمی", c: "prelingerhomemovies" },
        { id: "travel", fa: "سفر و جاهای دیدنی", t: "travelogue OR travel OR tourism OR vacation OR sightseeing" },
      ],
    },
    {
      id: "transport", fa: "حمل‌ونقل", en: "Transport", icon: "plane",
      topics: [
        { id: "planes", fa: "هواپیما و پرواز", t: "airplane OR airplanes OR aircraft OR aviation OR airline OR jet OR airport" },
        { id: "trains", fa: "قطار", t: "train OR trains OR railroad OR railway OR locomotive OR subway" },
        { id: "cars", fa: "ماشین‌های قدیمی", t: 'automobile OR automobiles OR "motor car" OR highway OR "auto show" OR chevrolet OR ford' },
        { id: "ships", fa: "کشتی و دریا", t: 'ship OR ships OR navy OR "ocean liner" OR submarine OR boat' },
        { id: "zeppelin", fa: "زپلین و بالن", t: "zeppelin OR airship OR hindenburg OR balloon OR blimp" },
        { id: "racing", fa: "مسابقه‌ی ماشین و موتور", t: '"auto racing" OR "race car" OR motorcycle OR speedway OR "indianapolis 500"' },
      ],
    },
    {
      id: "industry", fa: "صنعت و کار", en: "Industry & work", icon: "gear",
      topics: [
        { id: "factory", fa: "کارخانه و خط تولید", t: 'factory OR "assembly line" OR manufacturing OR industry OR industrial' },
        { id: "oil", fa: "نفت و انرژی", t: 'oil OR petroleum OR refinery OR "oil well" OR gasoline OR "oil field" OR "oil industry"' },
        { id: "mining", fa: "معدن و فولاد", t: 'mining OR miners OR "coal mine" OR steel OR coal OR "steel mill" OR quarry' },
        { id: "build", fa: "ساخت‌وساز، سد و پل", t: "construction OR skyscraper OR dam OR bridge OR building OR architecture" },
        { id: "farm", fa: "کشاورزی", t: "farming OR agriculture OR farm OR harvest OR tractor OR wheat" },
        { id: "workers", fa: "کارگر و کارمند", t: "workers OR office OR secretary OR typing OR labor OR jobs" },
      ],
    },
    {
      id: "money", fa: "پول و اقتصاد", en: "Money & economy", icon: "coin",
      topics: [
        { id: "stocks", fa: "بورس و وال‌استریت", t: '"stock market" OR "wall street" OR "stock exchange" OR "new york stock exchange"' },
        { id: "crash", fa: "سقوط بازار ۱۹۲۹", t: '"stock market crash" OR "crash of 1929" OR "black tuesday" OR "great depression"' },
        { id: "bank", fa: "پول و بانک", t: "money OR bank OR banking OR currency OR dollar OR savings" },
        { id: "gold", fa: "طلا", t: 'gold OR "gold rush" OR "gold mining" OR "fort knox"' },
        { id: "selling", fa: "فروش و بازاریابی", t: 'salesmanship OR selling OR salesman OR advertising OR marketing OR "supermarket"' },
        { id: "business", fa: "شرکت‌ها و تجارت", t: 'business OR corporation OR "free enterprise" OR economics OR capitalism' },
      ],
    },
    {
      id: "ads", fa: "تبلیغات، تلویزیون و کارتون", en: "Ads, TV & cartoons", icon: "tv", fiction: true,
      topics: [
        { id: "commercials", fa: "تبلیغات تلویزیونی قدیمی", c: "classic_tv_commercials", t: '"tv commercial" OR commercials', type: "movies" },
        { id: "cartoons", fa: "کارتون‌های قدیمی", c: "classic_cartoons animationandcartoons", t: "cartoon OR cartoons", type: "movies" },
        { id: "tvshows", fa: "برنامه‌های تلویزیونی قدیمی", c: "classic_tv", type: "movies" },
        { id: "computerads", fa: "تبلیغ کامپیوتر و بازی", c: "computercommercials videogamecommercials", type: "movies" },
        { id: "posters", fa: "پوستر و آگهی چاپی", t: "poster OR posters OR advertisement OR advertisements OR billboard", type: "image" },
      ],
    },
    {
      id: "cinema", fa: "سینمای کلاسیک", en: "Classic cinema", icon: "film", fiction: true,
      topics: [
        { id: "silent", fa: "فیلم‌های صامت", c: "silent_films", type: "movies" },
        { id: "noir", fa: "نوآر", c: "Film_Noir", type: "movies" },
        { id: "scifi", fa: "علمی‌تخیلی و وحشت", c: "SciFi_Horror", type: "movies" },
        { id: "comedy", fa: "کمدی کلاسیک", c: "Comedy_Films", t: 'chaplin OR "buster keaton" OR "laurel and hardy" OR "three stooges"', type: "movies" },
        { id: "trailers", fa: "تریلرهای قدیمی", c: "movie_trailers", type: "movies" },
        { id: "features", fa: "فیلم‌های بلند", c: "feature_films", type: "movies" },
      ],
    },
    {
      id: "sports", fa: "ورزش", en: "Sports", icon: "ball",
      topics: [
        { id: "olympics", fa: "المپیک", t: "olympic OR olympics" },
        { id: "football", fa: "فوتبال", t: 'soccer OR "world cup" OR "association football"' },
        { id: "wrestling", fa: "کشتی و بوکس", t: "wrestling OR boxing OR boxer OR wrestler" },
        { id: "athletics", fa: "دوومیدانی، شنا و ژیمناستیک", t: 'athletics OR "track and field" OR swimming OR gymnastics OR marathon' },
        { id: "fitness", fa: "ورزش و تناسب اندام", t: "exercise OR fitness OR calisthenics OR gym OR bodybuilding" },
      ],
    },
    {
      id: "free", fa: "منابع آزاد مطمئن", en: "Reliably free sources", icon: "shield", licence: "free",
      topics: [
        { id: "nasa", fa: "ناسا", c: "nasa" },
        { id: "newsreels", fa: "نیوزریل‌های Universal", c: "universal_newsreels" },
        { id: "fedflix", fa: "فیلم‌های دولت آمریکا (FedFlix)", c: "fedflix usgovfilms" },
        { id: "prelinger", fa: "Prelinger با مجوز آزاد", c: "prelinger", and: "licenseurl:(*publicdomain* OR *zero*)" },
        { id: "pre1931", fa: "هر چیز قبل از ۱۹۳۱", q: "year:[1800 TO 1930]" },
      ],
    },
  ];
})(typeof globalThis !== "undefined" ? globalThis : window);
