@echo off
rem NFP Archive: starts the local helper and opens the page in the browser. Keep this window open while you use it.
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Get it from https://nodejs.org and run start.bat again.
  echo Without it you can still open NFP-Archive.html directly: links only, no direct downloads or clips.
  pause
  exit /b 1
)
if not exist NFP-Archive.html node build.mjs
node server.mjs --open
pause
