#!/bin/sh
# NFP Archive (macOS / Linux): starts the local helper and opens the page. Keep this window open while you use it.
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Get it from https://nodejs.org and run this again."
  echo "Without it you can still open NFP-Archive.html directly: links only, no direct downloads or clips."
  read -r _
  exit 1
fi
[ -f NFP-Archive.html ] || node build.mjs
node server.mjs --open
